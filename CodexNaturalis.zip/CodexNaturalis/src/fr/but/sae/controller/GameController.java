package fr.but.sae.controller;

import fr.but.sae.model.GameData;
import fr.but.sae.model.Player;
import fr.but.sae.model.Position;
import fr.but.sae.view.GameView;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event.Action;

import java.awt.*;
import java.io.IOException;

public class GameController {

	public GameController() {
	}

	// Méthode principale de la boucle de jeu
	private static boolean gameLoop(ApplicationContext context, GameData data, GameView view) {
		// Dessine la vue du jeu
		GameView.draw(context, view, data);

		// Attend ou récupère un événement (20ms)
		var event = context.pollOrWaitEvent(20);
		if (event == null) {
			return true;
		}
		var action = event.getAction();

		// Vérifie si le jeu est terminé
		if (data.end()) {
			return false;
		}

		// Gère les différents états du jeu
		if (data.gameState().equals("startgame")) {
			if (action == Action.POINTER_DOWN) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				int choice = data.choiceMenu(x, y, view);

				// Choix dans le menu de démarrage
				if (choice == 0) {
					data.players().add(new Player("Player"));
					data.changegameState(0);
				}
				if (choice == 1) {
					data.changegameState(1);
				}
				if (choice == 2) {
					return false;
				}
			}
		} else if (data.gameState().equals("multiplayerMenu")) {
			if (action == Action.POINTER_DOWN) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				int choice = data.choiceMenuMulti(x, y, view);

				// Choix dans le menu multijoueur
				if (choice == 0) {
					data.players().add(new Player("Player 1"));
					data.players().add(new Player("Player 2"));
					data.changegameState(1);
				}
				if (choice == 1) {
					data.players().add(new Player("Player 1"));
					data.players().add(new Player("Player 2"));
					data.players().add(new Player("Player 3"));
					data.changegameState(1);
				}
				if (choice == 2) {
					data.players().add(new Player("Player 1"));
					data.players().add(new Player("Player 2"));
					data.players().add(new Player("Player 3"));
					data.players().add(new Player("Player 4"));
					data.changegameState(1);
				}
				if (choice == 3) {
					data.players().add(new Player("Player 1"));
					data.players().add(new Player("Player 2"));
					data.players().add(new Player("Player 3"));
					data.players().add(new Player("Player 4"));
					data.players().add(new Player("Player 5"));
					data.changegameState(1);
				}
				if (choice == 6) {
					data.changegameState(-1);
				}
			}
		} else if (data.gameState().equals("startpick")) {
			if (action == Action.POINTER_DOWN) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				if (data.pickedCard(x, y, view) != -1) {
					data.changegameState(1);
				}
			}
		} else if (data.gameState().equals("startpick2")) {
			if (action == Action.POINTER_DOWN) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				if (data.pickedCard(x, y, view) != -1) {
					if (data.players().getLast().equals(data.currentPlayer())) {
						data.changegameState(1);
						data.changeCurrentPlayer();
					} else {
						data.changegameState(-1);
						data.changeCurrentPlayer();
					}
				}
			}
		} else if (data.gameState().equals("placingstartcard")) {
			if (action == Action.KEY_PRESSED) {
				String entry = event.getKey().toString();
				if (entry.equals("A")) {
					data.select(1);
				} else if (entry.equals("R") && data.selectedCard() != 0) {
					data.changeside();
				}
			} else if (action == Action.POINTER_DOWN && data.selectedCard() != 0) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				Position playedPosition = data.clickOnPlayablePosition(x, y, view);
				if (playedPosition != null) {
					if (data.playCard(playedPosition)) {
						data.startPick();
						if (data.players().get(data.players().size() - 1).equals(data.currentPlayer())) {
							data.changegameState(1);
							data.changeCurrentPlayer();
						} else {
							data.changeCurrentPlayer();
						}
					}
					data.select(0);
				}
			}
		} else if (data.gameState().equals("play")) {
			if (action == Action.KEY_PRESSED) {
				String entry = event.getKey().toString();

				if (entry.equals("A")) {
					if (data.selectedCard() == 1) data.select(0);
					else data.select(1);
				} else if (entry.equals("Z")) {
					if (data.selectedCard() == 2) data.select(0);
					else data.select(2);
				} else if (entry.equals("E")) {
					if (data.selectedCard() == 3) data.select(0);
					else data.select(3);
				} else if (entry.equals("R") && data.selectedCard() != 0) {
					data.changeside();
				} else if (entry.equals("LEFT")) {
					data.moveBoard(1);
				} else if (entry.equals("UP")) {
					data.moveBoard(2);
				} else if (entry.equals("RIGHT")) {
					data.moveBoard(3);
				} else if (entry.equals("DOWN")) {
					data.moveBoard(4);
				}
			} else if (action == Action.POINTER_DOWN && data.selectedCard() != 0) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				Position playedPosition = data.clickOnPlayablePosition(x, y, view);
				if (playedPosition != null) {
					if (data.playCard(playedPosition)) {
						data.changegameState(1);
					}
					data.select(0);
				}
			}
		} else if (data.gameState().equals("endgame")) {
			data.endGame();
			if (action == Action.POINTER_DOWN) {
				data.changegameState(1);
				}
		} else {
			if (action == Action.POINTER_DOWN) {
				float x = event.getLocation().x;
				float y = event.getLocation().y;
				if (data.pickedCard(x, y, view) != -1) {
					data.changegameState(1);
					data.changeCurrentPlayer();
					data.moveBoard(0);
				}
			} else if (action == Action.KEY_PRESSED) {
				String entry = event.getKey().toString();

				if (entry.equals("LEFT")) {
					data.moveBoard(1);
				} else if (entry.equals("UP")) {
					data.moveBoard(2);
				} else if (entry.equals("RIGHT")) {
					data.moveBoard(3);
				} else if (entry.equals("DOWN")) {
					data.moveBoard(4);
				}
			}
		}
		return true;
	}

	// Méthode principale pour démarrer le jeu
	private static void codexNaturalis(ApplicationContext context) {
		var screenInfo = context.getScreenInfo();
		var width = screenInfo.getWidth();
		var height = screenInfo.getHeight();
		try {
			var data = new GameData();
			while (true) {
				var view = new GameView((int) height, (int) width, data, new Position(20, 100), new Position((int) width - 300, (int) height - 250));
				if (!gameLoop(context, data, view)) {
					context.exit(0);
					return;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			context.exit(1);
		}
	}

	// Méthode main pour lancer l'application
	public static void main(String[] args) {
		Application.run(new Color(232, 220, 202), GameController::codexNaturalis);
	}
}
