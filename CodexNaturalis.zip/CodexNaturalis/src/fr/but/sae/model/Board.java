package fr.but.sae.model;

import fr.but.sae.model.card.Card;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class Board {
    // Liste de cartes présentes sur le plateau
    private final ArrayList<Card> board;
    // HashMap pour compter les occurrences de chaque type de ressource
    private final HashMap<String, Integer> count;

    // Constructeur de la classe Board
    public Board() {
        board = new ArrayList<Card>();
        count = new HashMap<String, Integer>();
    }

    // Méthode pour ajouter une carte au plateau
    public void add(Card c) {
        Objects.requireNonNull(c);  // Vérifie que la carte n'est pas null
        board.add(c);  // Ajoute la carte à la liste des cartes sur le plateau
        c.coverCorner(this);  // Appelle la méthode coverCorner de la carte
    }

    // Méthode pour obtenir une carte à une position spécifique
    public Card get(int i) {
        return board.get(i);
    }

    // Méthode pour obtenir les positions jouables sur le plateau
    public ArrayList<Position> playablePlace() {
        ArrayList<Position> PlaceList = new ArrayList<Position>();
        if (board.size() == 0) {
            // Si le plateau est vide, ajoute la position initiale
            PlaceList.add(new Position(0, 0));
            return PlaceList;
        } else {
            // Parcourt toutes les cartes du plateau
            for (Card c : board) {
                // Ajoute les positions jouables retournées par chaque carte
                PlaceList.addAll(c.playableneighbor(board));
            }
            return PlaceList;
        }
    }

    // Méthode pour mettre à jour le compteur de ressources
    public void updateCount() {
        // Réinitialise le compteur pour chaque type de ressource
        for (String key : count.keySet()) {
            count.put(key, 0);
        }
        // Parcourt toutes les cartes du plateau
        for (Card card : board) {
            // Obtient le compte des ressources de la carte
            var cardcount = card.countResource();
            // Met à jour le compteur global avec les valeurs de la carte
            for (String element : cardcount.keySet()) {
                count.put(element, count.getOrDefault(element, 0) + cardcount.get(element));
            }
        }
    }

    // Méthode pour obtenir la liste des cartes sur le plateau
    public ArrayList<Card> board() {
        return board;
    }

    // Méthode pour obtenir le compteur de ressources
    public HashMap<String, Integer> count() {
        return count;
    }
}





