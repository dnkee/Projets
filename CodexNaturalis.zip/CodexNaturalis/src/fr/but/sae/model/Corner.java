package fr.but.sae.model;

import java.util.Objects;

public class Corner {
    // Champs pour stocker l'espèce, la position et l'existence du coin
    private final String specie;
    private final Position position;
    private final boolean existence;
    private boolean isCovered; // Indique si le coin est couvert

    // Constructeur avec spécification de l'espèce
    public Corner(String specie, Position position, boolean existence) {
        this.specie = Objects.requireNonNull(specie); // Vérifie que specie n'est pas null
        this.position = Objects.requireNonNull(position); // Vérifie que position n'est pas null
        this.existence = Objects.requireNonNull(existence); // Vérifie que existence n'est pas null
        isCovered = false; // Initialise isCovered à false
    }

    // Constructeur sans spécification de l'espèce
    public Corner(Position position, boolean existence) {
        this.position = Objects.requireNonNull(position); // Vérifie que position n'est pas null
        this.existence = Objects.requireNonNull(existence); // Vérifie que existence n'est pas null
        this.specie = "null"; // Définit specie à "null"
        isCovered = false; // Initialise isCovered à false
    }

    // Méthode pour vérifier si le coin est couvert
    public boolean isCovered() {
        return isCovered;
    }

    // Méthode pour définir le coin comme couvert
    public void setCovered() {
        isCovered = true;
    }

    // Accesseur pour obtenir la position du coin
    public Position position() {
        return position;
    }

    // Accesseur pour obtenir l'espèce du coin
    public String specie() {
        return specie;
    }

    // Méthode pour convertir un coin en position relative à une autre position
    public Position cornertoPosition(Position p) {
        return new Position(position.x() + p.x(), position.y() + p.y());
    }

    // Méthode pour vérifier l'existence du coin
    public boolean existence() {
        return existence;
    }
}
