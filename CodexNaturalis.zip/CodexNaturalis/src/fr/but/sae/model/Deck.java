package fr.but.sae.model;

import fr.but.sae.model.card.Card;

import java.util.ArrayList;
import java.util.Objects;

public class Deck {
    // Liste pour stocker les cartes du deck
    private ArrayList<Card> cards;

    // Constructeur de la classe Deck
    public Deck() {
        cards = new ArrayList<Card>(); // Initialise la liste des cartes
    }

    // Méthode pour obtenir une carte du deck à une position donnée (1-based index)
    public Card get(int n) {
        return cards.get(n - 1); // L'index est décalé de 1 pour correspondre à un index basé sur 1
    }

    // Méthode pour supprimer une carte du deck
    public void remove(Card c) {
        Objects.requireNonNull(c); // Vérifie que la carte n'est pas null
        cards.remove(c); // Supprime la carte du deck
    }

    // Méthode pour ajouter une carte au deck
    public void add(Card c) {
        cards.add(c); // Ajoute la carte au deck
    }

    // Méthode pour obtenir toutes les cartes du deck
    public ArrayList<Card> cards() {
        return cards; // Retourne la liste des cartes
    }
}
