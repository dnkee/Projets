package fr.but.sae.model;
import fr.but.sae.model.card.Card;
import fr.but.sae.model.card.Objective;
import fr.but.sae.view.GameView;
import java.nio.file.Path;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

public class GameData {
	private final ArrayList<Player> players=new ArrayList<>();
	private String gameState;
	private final Reserve reserve=new Reserve();
	private final ArrayList<Position> cornerpositions =new ArrayList<>();
	private int selectedCard;
	private boolean isVerso;
	private int currentPlayer;
	private boolean end;
	private final Objective commonObjective;
	private final ArrayList<Integer> objectivesSelection=new ArrayList<>();
	private Position boardPosition;
	public GameData() throws IOException {
		end=false;
		cornerpositions.add(new Position(-1,-1));
		cornerpositions.add(new Position(-1,1));
		cornerpositions.add(new Position(1,-1));
		cornerpositions.add(new Position(1,1));
		reserve.createReserve(Path.of("src/fr/but/sae/model/deck.txt"),cornerpositions);
		gameState="startgame";
		int x=ThreadLocalRandom.current().nextInt(0, reserve.size().get("Objective")-1);
		commonObjective=reserve.getObjective(x);
		reserve.remove(x+12);
		selectedCard=0;
		isVerso=false;
		currentPlayer=0;
		boardPosition=new Position(0,0);
		choiceObjective();
	}
	//Methode permettant de savoir si le jeu est fini
	public boolean end(){
		if(gameState.equals("end")){
			end=true;
		}
		else{
			end=false;
		}
		return end;
	}
	//Methode permettant de piocher automatiquement les trois première cartes
	public void startPick () {
		currentPlayer().pick(3, reserve);
		currentPlayer().pick(0, reserve);
		currentPlayer().pick(0, reserve);
	}
	//Accesseur pour la pioche
	public Reserve reserve() {
		return reserve;
	}
	//Methode permettant de changer le GameState pour avancer dans la boucle du jeu.
	public void changegameState(int i){
		if(gameState.equals("play") ){
				if(i!=-1)gameState="pick";
				else gameState="endgame";

		}
		else if(gameState.equals("endgame"))
		{gameState="end";
		}
			else if(gameState.equals("startpick"))
			{gameState="startpick2";
			}
			else if(gameState.equals("startpick2"))
			{
				if(i==1)gameState="placingstartcard";
				else gameState="startpick";
			}
			else if(gameState.equals("placingstartcard"))
			{gameState="play";}
			else if(gameState.equals("startgame") ){
				if(i==0){
					gameState="startpick";
				}
				if(i==1){
					gameState="multiplayerMenu";
				}
			}
			else if (gameState.equals("multiplayerMenu") ){
				if(i==1){

					gameState="startpick";}
				if(i==-1 ){
					gameState="startgame";
				}
				}
			else{
				gameState="play";
			}
		System.out.println(gameState);

	}
	//Methode permettant de selectionner une carte
	public void select(int n){
		selectedCard=n;
	}
	//Accesseur
	public int selectedCard() {
		return selectedCard;
	}
	//Methode permettant de convertir la position d'une carte dans la board dans une position réel pour l'affichage.
	public Position cardPositionToRealPosition(Position p, GameView view){
		var xPlace=boardPosition.x()+view.boardRealPosition().x()+(view.boardSize().x()/2)-50+80*p.x();
		var yPlace=boardPosition.y()+view.boardRealPosition().y()+(view.boardSize().y()/2)-15+40*p.y();
		return new Position(xPlace,yPlace);
	}

	//Méthode pour savoir si notre clique est sur une position jouable .
	public Position clickOnPlayablePosition(float x, float y, GameView view){
		if(x>=view.boardRealPosition().x() && x<=view.boardSize().x()+view.boardRealPosition().x() && y>=view.boardRealPosition().y() && y<=view.boardSize().y()+view.boardRealPosition().y()){
			for (Position p : players.get(currentPlayer).board().playablePlace()){
				var posi = cardPositionToRealPosition(p,view);
				if (posi.inPlace(x,y)){
					return p;
				}
			}
		}

		return null;
	}
	//Methode pour jouer une carte.
	public boolean playCard(Position p){
		Card c= players.get(currentPlayer).deck().get(selectedCard());
		if(!players.get(currentPlayer).play(c,p,isVerso)){
			return false;
		}
		players.get(currentPlayer).board().updateCount();
		System.out.println(players.get(currentPlayer).board().count());

		isVerso=false;
		return true;
	}

	//Methode pour gérer les clique lors de la pioche de carte. Regarde si la position du clique est dans la carte.
	public int pickedCard(float x, float y, GameView view){
		if(gameState.equals("startpick")){
			int numberPlayer=reserve().size().get("StarterCard");
			var x2 = -200;
			var y2 = -70;
			for (int i=0;i<numberPlayer;i++){
				if ((view.width()/2)+x2<=x && x<=(view.width()/2)+x2+100 &&  y>=(view.height()/2)+y2 && y<=(view.height()/2)+y2+60){
					players.get(currentPlayer).pick(6+i,reserve);
					return 6+i;
				}
				x2+=150;
				if (i==2){
					y2=10;
					x2=-200;
				}
			}
		}
		else if (gameState.equals("startpick2")) {

			if(view.width()/2>=x && x>=view.width()/2-100 && view.height()/2+160>=y && view.height()/2+100<=y){
				players.get(currentPlayer).setObjective(reserve.getObjective(objectivesSelection.get(0)));
				reserve.remove(objectivesSelection.getFirst()+12);
				return 1;
			}
			else if(view.width()/2+150>=x && x>=view.width()/2+50 && view.height()/2+160>=y && view.height()/2+100<=y){
				players.get(currentPlayer).setObjective(reserve.getObjective(objectivesSelection.get(1)));
				reserve.remove(objectivesSelection.get(1)+12);
				return 2;
			}

		}
		else{
		if(view.width()-140>=x && x>=view.width()-240 && 130>=y && 70<=y){
			players.get(currentPlayer).pick(5,reserve);
			return 5;
		}
		else if(view.width()-140>=x && x>=view.width()-240 && 210>=y && 150<=y){
			players.get(currentPlayer).pick(4,reserve);
			return 4;
		}
		else if(view.width()-140>=x && x>=view.width()-240 && 290>=y && 230<=y){
			players.get(currentPlayer).pick(3,reserve);
			return 3;
		}
		else if(view.width()-20>=x && x>=view.width()-120 && 130>=y && 70<=y){
			players.get(currentPlayer).pick(2,reserve);
			return 2;
		}
		else if(view.width()-20>=x && x>=view.width()-120 && 210>=y && 150<=y){
			players.get(currentPlayer).pick(1,reserve);
			return 1;
		}
		else if(view.width()-20>=x && x>=view.width()-120 && 290>=y && 230<=y){
			players.get(currentPlayer).pick(0,reserve);
			return 0;
		}
		}
		return -1;
	}


	//Méthode renvoyant le joueur actuellement en train de jouer
	public Player currentPlayer() {
		return players.get(currentPlayer);
	}
	//Méthode permettant de changer le joueur actuel
	public void changeCurrentPlayer(){
		currentPlayer++;
		choiceObjective();
		if(reserve.isEmpty()){
			changegameState(-1);

		}
		if(currentPlayer==players.size()){
			if(isEndGame()){
				System.out.println("end");
				changegameState(-1);
			}
			currentPlayer=0;
		}

	}


	public ArrayList<Player> players() {
		return players;
	}

	//Méthode permettant de gérer les cliques dans le menu principal.
	public int choiceMenu(float x, float y,GameView view) {
		var x2 = (view.width() / 2) - 200;
		var y2 = 200;
		for (int i = 0; i < 3; i++) {
			if (x2 <= x && x <= x2 + 400 && y >= y2 && y <= y2 + 100) {
				return i;
			}
			y2 += 200;
		}
		return -1;
	}
	//Méthode permettant de gérer les cliques dans le menu multijoueur.
	public int choiceMenuMulti(float x, float y,GameView view) {
		var x2 = (view.width() / 2) - 50;
		var y2 = 100;
		if (100 <= x && x <= 200 && y >= 100 && y <= 200) return 6;
		for (int i = 0; i < 4; i++) {
			if (x2 <= x && x <= x2 + 100 && y >= y2 && y <= y2 + 100) {

				return i;
			}
			y2 += 200;
		}
		return -1;
	}
	//Méthode permettant de se déplacer dans l'espace de jeu.
	public void moveBoard(int i) {
		if(i==1){
			boardPosition=new Position(boardPosition.x()-5,boardPosition.y());
		}
		else if(i==2){
			boardPosition=new Position(boardPosition.x(),boardPosition.y()-5);
		}
		else if(i==3){
			boardPosition=new Position(boardPosition.x()+5,boardPosition.y());
		}
		else if(i==4){
			boardPosition=new Position(boardPosition.x(),boardPosition.y()+5);
		}
		else{
			boardPosition=new Position(0,0);
		}
	}

	public String gameState(){
		return gameState;
	}
	//Methode déterminant si la partie est finie
	public boolean isEndGame() {
		for (Player p : players) {
			if (p.score() >= 20) {
			System.out.println("Fin");
				return true;
			}

		}
		return false;
	}
	//Methode qui gère le calcul du score final pour chaque joueur
	public HashMap<Player,Integer> endGame() {
		HashMap<Player,Integer> result = new HashMap<Player,Integer>();
		for (Player p : players) {
			int score =p.score()+p.objectiveScore(commonObjective);
			result.put(p,score);
		}
		return result;
	}

	//Méthode pour accéder au verso de la carte
	public void changeside(){
		if (isVerso) isVerso=false;
		else isVerso=true;
	}
	public boolean isVerso(){
		return isVerso;
	}

	//Choisi deux objectifs aléatoirement
	public void choiceObjective() {
		int firstObjective =ThreadLocalRandom.current().nextInt(0, reserve().size().get("Objective")-1);
		int secondObjective =ThreadLocalRandom.current().nextInt(0, reserve().size().get("Objective")-1);
		while(firstObjective==secondObjective){
			secondObjective =ThreadLocalRandom.current().nextInt(0, reserve().size().get("Objective")-1);
		}
		if(objectivesSelection.size()==2){
			objectivesSelection.remove(0);
			objectivesSelection.remove(0);
		}
		objectivesSelection.add(firstObjective);
		objectivesSelection.add(secondObjective);
		}

	public ArrayList<Integer> objectivesSelection() {
		return objectivesSelection;
	}

	//Determine le gagnant de la partie
	public Player winner(){
	Player p =players.get(0);
	int max =players.get(0).score();
		for (Player player : players){
			if (player.score() > max) {
				max=player.score();
				p=player;
			}
		}
		return p;
	}
	public Objective commonObjective(){
		return commonObjective;
	}



}




