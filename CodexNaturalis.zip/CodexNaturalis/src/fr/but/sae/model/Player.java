package fr.but.sae.model;

import fr.but.sae.model.card.Card;
import fr.but.sae.model.card.Objective;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Player {
    // Score du joueur
    private int score;
    // Plateau du joueur
    private final Board board;
    // Deck de cartes du joueur
    private final Deck deck;
    // Nom du joueur
    private final String name;
    // Objectif personnel du joueur
    private Objective personalObjective;

    // Constructeur de la classe Player
    public Player(String name) {
        deck = new Deck();
        board = new Board();
        score = 0;
        this.name = name;
        this.personalObjective = null;
    }

    // Méthode pour piocher une carte dans la réserve
    public void pick(int n, Reserve reserve) {
        Objects.requireNonNull(reserve);  // Vérifie que la réserve n'est pas null
        var c = reserve.get(n);  // Récupère la carte de la réserve
        reserve.remove(n);  // Retire la carte de la réserve
        deck.add(c);  // Ajoute la carte au deck du joueur
    }

    // Méthode pour jouer une carte à une position donnée
    public boolean play(Card c, Position p, boolean isVerso) {
        Objects.requireNonNull(c);  // Vérifie que la carte n'est pas null
        Objects.requireNonNull(p);  // Vérifie que la position n'est pas null
        if (isVerso) {
            c.verso().place(p);  // Place la carte verso à la position donnée
            deck.remove(c);  // Retire la carte du deck
            board.add(c.verso());  // Ajoute la carte verso au plateau
            this.addPoint(c.verso());  // Ajoute les points de la carte verso
            return true;
        } else {
            if (c.requirementAccepted(board)) {
                c.place(p);  // Place la carte à la position donnée
                deck.remove(c);  // Retire la carte du deck
                board.add(c);  // Ajoute la carte au plateau
                this.addPoint(c);  // Ajoute les points de la carte
                return true;
            }
        }
        return false;
    }

    // Méthode pour ajouter les points d'une carte au score du joueur
    public void addPoint(Card c) {
        Objects.requireNonNull(c);  // Vérifie que la carte n'est pas null
        score += c.pointscored(board);  // Ajoute les points de la carte au score
    }

    // Méthode pour calculer le score en fonction des objectifs
    public int objectiveScore(Objective commonObjective) {
        int score = 0;
        if (commonObjective.isPattern()) {
            // Traitement pour les objectifs de type pattern
            String typeFirstCard = commonObjective.getTypeFromPosition(new Position(0, 0));
            for (Card card : board.board()) {
                int count = 0;
                int size = commonObjective.pattern().keySet().size();
                if (card.type().equals(typeFirstCard)) {
                    for (Position posi : commonObjective.pattern().keySet()) {
                        Position position = new Position(posi.x() + card.position().x(), posi.y() + card.position().y());
                        String typeCard = commonObjective.getTypeFromPosition(posi);
                        for (Card card2 : board.board()) {
                            if (card2.position().equals(position)) {
                                if (card2.type().equals(typeCard)) {
                                    count++;
                                }
                                break;
                            }
                        }
                    }
                }
                if (count == size) {
                    score += commonObjective.score();
                }
            }
        } else {
            // Traitement pour les objectifs de type artefact
            var count = board.count();
            List<String> list = List.copyOf(commonObjective.artefactList().keySet());
            String s = list.getFirst();

            int point = count.getOrDefault(s, 0) / commonObjective.artefactList().get(s);
            for (int i = 1; i < list.size(); i++) {
                s = list.get(i);
                if (count.getOrDefault(s, 0) / commonObjective.artefactList().get(s) < point) {
                    point = count.getOrDefault(s, 0) / commonObjective.artefactList().get(s);
                }
            }
            score += point * commonObjective.score();
        }
        if (personalObjective.isPattern()) {
            // Traitement pour les objectifs personnels de type pattern
            String typeFirstCard = personalObjective.getTypeFromPosition(new Position(0, 0));
            for (Card card : board.board()) {
                int count = 0;
                int size = personalObjective.pattern().keySet().size();
                if (card.type().equals(typeFirstCard)) {
                    for (Position posi : personalObjective.pattern().keySet()) {
                        Position position = new Position(posi.x() + card.position().x(), posi.y() + card.position().y());
                        String typeCard = personalObjective.getTypeFromPosition(posi);
                        for (Card card2 : board.board()) {
                            if (card2.position().equals(position)) {
                                if (card2.type().equals(typeCard)) {
                                    count++;
                                }
                                break;
                            }
                        }
                    }
                }
                if (count == size) {
                    score += personalObjective().score();
                }
            }
        } else {
            // Traitement pour les objectifs personnels de type artefact/resources
            var count = board.count();
            List<String> list = List.copyOf(personalObjective.artefactList().keySet());
            String s = list.getFirst();
            int point = count.getOrDefault(s, 0) / personalObjective.artefactList().get(s);
            for (int i = 1; i < list.size(); i++) {
                s = list.get(i);
                if (count.getOrDefault(s, 0) / personalObjective.artefactList().get(s) < point) {
                    point = count.getOrDefault(s, 0) / personalObjective.artefactList().get(s);
                }
            }
            score += point * personalObjective.score();
        }

        return score;
    }

    // Méthode pour définir l'objectif personnel du joueur
    public void setObjective(Objective personalObjective) {
        this.personalObjective = personalObjective;
    }

    // Méthode pour obtenir le score du joueur
    public int score() {
        return score;
    }

    // Méthode pour obtenir le deck du joueur
    public Deck deck() {
        return deck;
    }

    // Méthode pour obtenir le plateau du joueur
    public Board board() {
        return board;
    }

    // Méthode pour obtenir le nom du joueur
    public String name() {
        return name;
    }

    // Méthode pour obtenir l'objectif personnel du joueur
    public Objective personalObjective() {
        return personalObjective;
    }
}




