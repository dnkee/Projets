package fr.but.sae.model;

import fr.but.sae.model.card.Card;

import java.util.ArrayList;
import java.util.Objects;

public record Position(int x, int y) {

    // Méthode privée pour obtenir les positions adjacentes en diagonale
    private ArrayList<Position> closePositions() {
        ArrayList<Position> closePositions = new ArrayList<>();
        closePositions.add(new Position(x - 1, y - 1));
        closePositions.add(new Position(x + 1, y - 1));
        closePositions.add(new Position(x - 1, y + 1));
        closePositions.add(new Position(x + 1, y + 1));
        return closePositions;
    }

    // Vérifie si la position est occupée sur le plateau
    public boolean isPositiontaken(ArrayList<Card> board) {
        for (Card c : board) {
            if (c.position().equals(this)) {  // Utilise equals pour comparer les positions
                return true;
            }
        }
        return false;
    }

    // Vérifie si les coordonnées (x, y) se trouvent dans la zone de la position
    public boolean inPlace(float x, float y) {
        return (x > this.x() && x < this.x() + 100) && y > this.y() && y < this.y() + 60;
    }

    // Vérifie si la position est un endroit où une carte peut être placée
    public boolean isAPlacablePlace(ArrayList<Card> board) {
        int cornercount = 0;
        for (Card c : board) {
            if (c.position().x() == x && c.position().y() == y) {
                return false;
            }
        }
        for (Position p : closePositions()) {
            for (Card c : board) {
                if (c.position().x() == p.x() && c.position().y() == p.y()) {
                    for (Corner corner : c.cornerlist()) {
                        if (p.x() + corner.position().x() == x && p.y() + corner.position().y() == y) {
                            if (!corner.existence()) {
                                return false;
                            } else {
                                cornercount++;
                            }
                        }
                    }
                }
            }
        }
        return cornercount > 0;
    }

    // Représentation sous forme de chaîne de la position
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    // Redéfinition de la méthode equals pour comparer les positions
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Position position = (Position) obj;
        return x == position.x && y == position.y;  // Compare les valeurs des coordonnées
    }

    // Redéfinition de la méthode hashCode pour générer un code de hachage basé sur les coordonnées
    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}
