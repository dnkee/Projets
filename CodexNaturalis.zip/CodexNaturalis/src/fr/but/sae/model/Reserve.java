package fr.but.sae.model;

import fr.but.sae.model.card.Card;
import fr.but.sae.model.card.Gilding;
import fr.but.sae.model.card.Objective;
import fr.but.sae.model.card.Resource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Reserve {
    // Listes pour stocker différents types de cartes
    private final ArrayList<Gilding> gildings;
    private final ArrayList<Resource> resources;
    private final ArrayList<Resource> startcards;
    private final ArrayList<Objective> objectives;

    // Constructeur de la classe Reserve
    public Reserve() {
        gildings = new ArrayList<>();
        resources = new ArrayList<>();
        startcards = new ArrayList<>();
        objectives = new ArrayList<>();
    }

    // Méthode pour créer la réserve à partir d'un fichier
    public void createReserve(Path path, ArrayList<Position> cornerPositions) throws IOException {
        try {
            // Lire toutes les lignes du fichier
            List<String> lines = Files.readAllLines(path);
            // Mélanger les lignes pour randomiser l'ordre des cartes
            Collections.shuffle(lines);
            // Réécrire les lignes dans le fichier
            Files.write(path, lines);
        } catch (IOException e) {
            System.err.println("Une erreur s'est produite lors de la lecture ou de l'écriture du fichier : " + e.getMessage());
        }
        try (var reader = Files.newBufferedReader(path)) {
            String line;
            // Lire le fichier ligne par ligne
            while ((line = reader.readLine()) != null) {
                addCardFromLine(line, cornerPositions);
            }
        }
    }

    // Méthode pour ajouter une carte à partir d'une ligne de texte
    public void addCardFromLine(String line, ArrayList<Position> cornerPositions) {
        String[] arrayLine = line.split(" ");
        switch (arrayLine[0]) {
            case "Objective":
                objectives.add(Objective.createObjectiveFromLine(arrayLine));
                break;
            case "StarterCard":
                startcards.add(Resource.createStartCardFromLine(arrayLine, cornerPositions));
                break;
            case "GoldCard":
                gildings.add(Gilding.createGildingFromLine(arrayLine, cornerPositions));
                break;
            case "ResourceCard":
                resources.add(Resource.createResourceFromLine(arrayLine, cornerPositions));
                break;
        }
    }

    // Méthode pour vérifier si la réserve est vide
    public boolean isEmpty() {
        return gildings.isEmpty() && resources.isEmpty();
    }

    // Méthode pour obtenir la taille des différents types de cartes dans la réserve
    public HashMap<String, Integer> size() {
        HashMap<String, Integer> map = new HashMap<>();
        map.put("Objective", objectives.size());
        map.put("StarterCard", startcards.size());
        map.put("GoldCard", gildings.size());
        map.put("ResourceCard", resources.size());
        return map;
    }

    // Méthode pour supprimer une carte de la réserve par index
    public void remove(int nb) {
        if (nb < 3) {
            gildings.remove(nb);
        } else if (nb < 6) {
            resources.remove(nb - 3);
        } else if (nb < 12) {
            startcards.remove(nb - 6);
        } else {
            objectives.remove(nb - 12);
        }
    }

    // Méthode pour obtenir une carte de la réserve par index
    public Card get(int nb) {
        if (nb < 3) {
            return gildings.get(nb);
        } else if (nb < 6) {
            return resources.get(nb - 3);
        } else {
            return startcards.get(nb - 6);
        }
    }

    // Méthode pour obtenir un objectif de la réserve par index
    public Objective getObjective(int nb) {
        return objectives.get(nb);
    }
}


