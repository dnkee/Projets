package fr.but.sae.model.card;

import fr.but.sae.model.Board;
import fr.but.sae.model.Corner;
import fr.but.sae.model.Position;

import java.util.ArrayList;
import java.util.HashMap;

public interface Card {
    public Position position();
    public boolean isResource();
    public ArrayList<Corner> cornerlist();
    public void place(Position p);
    public int pointscored(Board board);
    public ArrayList<Position> playableneighbor(ArrayList<Card> board);
    public HashMap<String, Integer> countResource();
    public String type();
    public Resource verso();
    public boolean requirementAccepted(Board board);
    public void coverCorner(Board board);
    public int point();
}

