package fr.but.sae.model.card;

import fr.but.sae.model.Board;
import fr.but.sae.model.Corner;
import fr.but.sae.model.Position;

import java.util.ArrayList;
import java.util.HashMap;

public class Gilding implements Card {
    // Attributs de la classe Gilding
    private final int point;
    private final String condition;
    private final ArrayList<Corner> cornerlist;
    private final HashMap<String,Integer> requirement;
    private final String type;
    private Position position;
    private final Resource verso;

    // Indique que cette carte n'est pas une ressource
    public boolean isResource(){
        return false;
    }

    // Constructeur de la classe Gilding
    public Gilding(int point, String condition, ArrayList<Corner> cornerlist, HashMap<String,Integer> requirement, String type) {
        this.point = point;
        this.condition = condition;
        this.cornerlist = cornerlist;
        this.requirement = requirement;
        this.position = null;
        this.type = type;
        verso = new Resource(type);
    }

    // Retourne les points de la carte
    public int point() {
        return point;
    }

    // Retourne la liste des coins de la carte
    @Override
    public ArrayList<Corner> cornerlist() {
        return cornerlist;
    }

    // Place la carte à une position donnée
    @Override
    public void place(Position p) {
        position = p;
    }

    // Retourne la position de la carte
    @Override
    public Position position() {
        return position;
    }

    // Couvre les coins adjacents sur le plateau
    public void coverCorner(Board board) {
        int i = 0;
        var neighborhood = new ArrayList<Position>();
        neighborhood.add(new Position(1, 1));
        neighborhood.add(new Position(-1, 1));
        neighborhood.add(new Position(1, -1));
        neighborhood.add(new Position(-1, -1));

        // Boucle pour trouver la carte dans le plateau et couvrir les coins adjacents
        while (this != board.board().get(i)) {
            for (Position p : neighborhood) {
                if (board.board().get(i).position().x() == position.x() + p.x() && board.get(i).position().y() == position.y() + p.y()) {
                    for (Corner corner : board.board().get(i).cornerlist()) {
                        if (-p.x() == (corner.position().x()) && -p.y() == (corner.position().y())) {
                            corner.setCovered();
                        }
                    }
                }
            }
            i++;
        }
    }

    // Calcule les points marqués selon la condition de la carte
    @Override
    public int pointscored(Board board) {
        int coef = 0;
        if (condition.equals("C")) {
            int i = 0;
            var neighborhood = new ArrayList<Position>();
            neighborhood.add(new Position(1, 1));
            neighborhood.add(new Position(-1, 1));
            neighborhood.add(new Position(1, -1));
            neighborhood.add(new Position(-1, -1));

            // Boucle pour compter les cartes adjacentes selon la condition "CoverCorner"
            while (this != board.get(i)) {
                for (Position p : neighborhood) {
                    if (board.get(i).position().x() == position.x() + p.x() && board.get(i).position().y() == position.y() + p.y()) {
                        coef++;
                        break;
                    }
                }
                i++;
            }
            return coef * point;
        }
        else if (condition.equals("I")) return board.count().getOrDefault("Inkwell", 0);
        else if (condition.equals("M")) return board.count().getOrDefault("Manuscript", 0);
        else if (condition.equals("Q")) return board.count().getOrDefault("Quill", 0);
        else {
            return point;
        }
    }

    // Retourne les positions jouables adjacentes à la carte
    @Override
    public ArrayList<Position> playableneighbor(ArrayList<Card> board) {
        var listPlayable = new ArrayList<Position>();
        for (Corner c : cornerlist) {
            var x = c.cornertoPosition(position);
            var z = x.isPositiontaken(board);

            if (!z) {
                if (x.isAPlacablePlace(board)) listPlayable.add(x);
            }
        }
        return listPlayable;
    }

    // Compte les ressources non couvertes sur la carte
    @Override
    public HashMap<String, Integer> countResource() {
        HashMap<String, Integer> count = new HashMap<>();
        for (Corner corner : cornerlist) {
            String specie = corner.specie();
            if (!corner.isCovered()) {
                if (count.keySet().contains(specie)) {
                    count.put(specie, count.get(specie) + 1);
                } else {
                    count.put(specie, 1);
                }
            }
        }
        return count;
    }

    // Vérifie si les conditions de la carte sont remplies
    public boolean requirementAccepted(Board board) {
        var keys = requirement.keySet();
        for (String key : keys) {
            if (board.count().getOrDefault(key, 0) < requirement.get(key)) {
                return false;
            }
        }
        return true;
    }

    // Méthode statique pour créer une instance de Gilding à partir d'une ligne de données
    public static Gilding createGildingFromLine(String[] arrayLine, ArrayList<Position> cornerpositions) {
        HashMap<String, Integer> requirement = new HashMap<>();
        ArrayList<Corner> cornersRecto = new ArrayList<>();

        // Traitement des coins de la carte
        for (int i = 0; i < 4; i++) {
            if (arrayLine[2 + i].equals("Invisible")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), false));
            } else if (arrayLine[2 + i].equals("Empty")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), true));
            } else if (arrayLine[2 + i].contains(":")) {
                var mot = arrayLine[2 + i].split(":");
                var corner = new Corner(mot[1], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            } else {
                var corner = new Corner(arrayLine[2 + i], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            }
        }

        String type = arrayLine[7];
        var mot = arrayLine[arrayLine.length - 1].split(":");
        String score = mot[1];
        String condition = mot[0];

        // Traitement des requirements de la carte
        for (int i = 9; i < arrayLine.length - 2; i++) {
            requirement.put(arrayLine[i], requirement.getOrDefault(arrayLine[i], 0) + 1);
        }

        return new Gilding(Integer.parseInt(score), condition, cornersRecto, requirement, type);
    }

    // Retourne le type de la carte
    @Override
    public String type() {
        return type;
    }

    // Retourne la condition de la carte
    public String condition() {
        return condition;
    }

    // Retourne le verso de la carte
    public Resource verso() {
        return verso;
    }

    // Retourne les requirements de la carte
    public HashMap<String, Integer> requirement() {
        return requirement;
    }
}
