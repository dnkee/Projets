package fr.but.sae.model.card;

import fr.but.sae.model.Board;
import fr.but.sae.model.Corner;
import fr.but.sae.model.Position;

import java.util.ArrayList;
import java.util.HashMap;

public class Objective {
    // Attributs de la classe Objective
    private final ArrayList<String> pattern;
    private final HashMap<String, Integer> artefactList;
    private int score;
    private final boolean isPattern;

    // Constructeur pour un objectif basé sur une liste d'artefacts
    public Objective(HashMap<String, Integer> artefactList, int score) {
        this.artefactList = artefactList;
        this.score = score;
        this.pattern = new ArrayList<>();
        isPattern = false;
    }

    // Constructeur pour un objectif basé sur un motif (pattern)
    public Objective(ArrayList<String> pattern, int score) {
        this.pattern = pattern;
        this.score = score;
        this.artefactList = new HashMap<>();
        isPattern = true;
    }

    // Méthode statique pour créer un objectif à partir d'une ligne de données
    public static Objective createObjectiveFromLine(String[] arrayLine) {
        if (arrayLine[1].equals("Pattern")) {
            ArrayList<String> pattern = new ArrayList<>();
            int i = 2;
            while (!arrayLine[i].equals("Scoring")) {
                pattern.add(arrayLine[i]);
                i++;
            }
            var mot = arrayLine[arrayLine.length - 1].split(":");
            int score = Integer.parseInt(mot[1]);
            return new Objective(pattern, score);
        } else {
            HashMap<String, Integer> artefactsList = new HashMap<>();
            int i = 2;
            while (!arrayLine[i].equals("Scoring")) {
                artefactsList.put(arrayLine[i], artefactsList.getOrDefault(arrayLine[i], 0) + 1);
                i++;
            }
            var mot = arrayLine[arrayLine.length - 1].split(":");
            int score = Integer.parseInt(mot[1]);
            return new Objective(artefactsList, score);
        }
    }

    // Retourne une carte du motif (pattern) avec leurs positions
    public HashMap<Position, String> pattern() {
        HashMap<Position, String> patternMap = new HashMap<>();
        String s = "";
        Position lastPosition = new Position(0, 0);
        Position position = new Position(0, 0);
        for (int i = 0; i < pattern.size(); i++) {
            if (i == 0) {
                patternMap.put(position, pattern.get(i));
            } else if (i % 2 == 0) {
                s = pattern.get(i);
                patternMap.put(position, s);
            } else {
                // Mise à jour de la position selon la direction indiquée
                if (pattern.get(i).equals("Top")) {
                    position = new Position(lastPosition.x(), lastPosition.y() - 2);
                } else if (pattern.get(i).equals("Bottom")) {
                    position = new Position(lastPosition.x(), lastPosition.y() + 2);
                } else if (pattern.get(i).equals("TopLeft")) {
                    position = new Position(lastPosition.x() - 1, lastPosition.y() - 1);
                } else if (pattern.get(i).equals("BottomLeft")) {
                    position = new Position(lastPosition.x() - 1, lastPosition.y() + 1);
                } else if (pattern.get(i).equals("TopRight")) {
                    position = new Position(lastPosition.x() + 1, lastPosition.y() - 1);
                } else {
                    position = new Position(lastPosition.x() + 1, lastPosition.y() + 1);
                }
                lastPosition = position;
            }
        }
        return patternMap;
    }

    // Retourne la liste des artefacts
    public HashMap<String, Integer> artefactList() {
        return artefactList;
    }

    // Indique si l'objectif est basé sur un motif (pattern)
    public boolean isPattern() {
        return isPattern;
    }

    // Retourne le score de l'objectif
    public int score() {
        return score;
    }

    // Retourne le type d'objectif à une position donnée
    public String getTypeFromPosition(Position p) {
        for (Position posi : pattern().keySet()) {
            if (posi.equals(p)) {
                return pattern().get(posi);
            }
        }
        return null;
    }

    // Redéfinition de la méthode toString pour afficher les détails de l'objectif
    public String toString() {
        return pattern + "," + artefactList.toString() + "," + score;
    }
}
