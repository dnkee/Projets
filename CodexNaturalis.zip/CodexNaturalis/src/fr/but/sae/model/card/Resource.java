package fr.but.sae.model.card;

import fr.but.sae.model.Board;
import fr.but.sae.model.Corner;
import fr.but.sae.model.Position;

import java.util.ArrayList;
import java.util.HashMap;

public class Resource implements Card {
    // Attributs de la classe Resource
    private final ArrayList<Corner> cornerlist;
    private Position position;
    private String type;
    private final Resource verso;
    private final boolean isVerso;
    private final boolean isStartCard;
    private final int point;
    private final HashMap<String,Integer> centerResourcesStartCard;

    // Indique que cette carte est une ressource
    public boolean isResource() {
        return true;
    }

    // Indique si cette carte est une carte de départ
    public boolean isStartCard() {
        return isStartCard;
    }

    // Retourne les ressources au centre de la carte de départ
    public HashMap<String,Integer> centerResourcesStartCard() {
        return centerResourcesStartCard;
    }

    // Constructeur pour une carte ressource normale
    public Resource(ArrayList<Corner> cornerlist, String type, int point) {
        this.cornerlist = cornerlist;
        this.position = null;
        this.type = type;
        this.isVerso = false;
        this.verso = new Resource(type);
        this.isStartCard = false;
        this.centerResourcesStartCard = new HashMap<>();
        this.point = point;
    }

    // Constructeur pour une carte ressource verso
    public Resource(String type) {
        var corners = new ArrayList<Corner>();
        corners.add(new Corner("null", new Position(1, -1), true));
        corners.add(new Corner("null", new Position(-1, 1), true));
        corners.add(new Corner("null", new Position(1, 1), true));
        corners.add(new Corner("null", new Position(-1, -1), true));
        this.cornerlist = corners;
        this.position = null;
        this.type = type;
        this.isVerso = true;
        this.verso = null;
        this.isStartCard = false;
        this.centerResourcesStartCard = new HashMap<>();
        this.point = 0;
    }

    // Constructeur pour une carte de départ avec verso spécifié
    public Resource(ArrayList<Corner> cornerlist, String type, Resource verso) {
        this.cornerlist = cornerlist;
        this.position = null;
        this.type = type;
        this.isVerso = false;
        this.isStartCard = true;
        this.centerResourcesStartCard = new HashMap<>();
        this.verso = verso;
        this.point = 0;
    }

    // Constructeur pour une carte de départ avec ressources centrales
    public Resource(ArrayList<Corner> cornerlist, String type, HashMap<String,Integer> centerResourcesStartCard) {
        this.cornerlist = cornerlist;
        this.position = null;
        this.type = type;
        this.isVerso = true;
        this.verso = new Resource(type);
        this.isStartCard = true;
        this.centerResourcesStartCard = centerResourcesStartCard;
        this.point = 0;
    }

    // Retourne la liste des coins de la carte
    @Override
    public ArrayList<Corner> cornerlist() {
        return cornerlist;
    }

    // Retourne la position de la carte
    @Override
    public Position position() {
        return position;
    }

    // Place la carte à une position donnée
    @Override
    public void place(Position p) {
        position = p;
    }

    // Retourne les points marqués par la carte (pour les ressources, c'est le même point)
    @Override
    public int pointscored(Board board) {
        return point;
    }

    // Retourne les positions jouables adjacentes à la carte
    @Override
    public ArrayList<Position> playableneighbor(ArrayList<Card> board) {
        var listPlayable = new ArrayList<Position>();
        for (Corner c : cornerlist) {
            var x = c.cornertoPosition(position);
            var z = x.isPositiontaken(board);
            if (!z) {
                if (x.isAPlacablePlace(board)) listPlayable.add(x);
            }
        }
        return listPlayable;
    }

    // Compte les ressources non couvertes sur la carte
    @Override
    public HashMap<String, Integer> countResource() {
        HashMap<String, Integer> count = new HashMap<>();
        if (isVerso) {
            if (isStartCard) {
                for (String specie : centerResourcesStartCard.keySet()) {
                    count.put(specie, centerResourcesStartCard.get(specie));
                }
            } else {
                count.put(type, 1);
                return count;
            }
        }
        for (Corner corner : cornerlist) {
            String specie = corner.specie();
            if (!corner.isCovered()) {
                count.put(specie, count.getOrDefault(specie, 0) + 1);
            }
        }
        return count;
    }

    // Couvre les coins adjacents sur le plateau
    public void coverCorner(Board board) {
        int i = 0;
        var neighborhood = new ArrayList<Position>();
        neighborhood.add(new Position(1, 1));
        neighborhood.add(new Position(-1, 1));
        neighborhood.add(new Position(1, -1));
        neighborhood.add(new Position(-1, -1));

        // Boucle pour trouver la carte dans le plateau et couvrir les coins adjacents
        while (this != board.board().get(i)) {
            for (Position p : neighborhood) {
                if (board.board().get(i).position().x() == position.x() + p.x() && board.board().get(i).position().y() == position.y() + p.y()) {
                    for (Corner corner : board.board().get(i).cornerlist()) {
                        if (-p.x() == (corner.position().x()) && -p.y() == (corner.position().y())) {
                            corner.setCovered();
                        }
                    }
                }
            }
            i++;
        }
    }

    // Crée une carte de départ à partir d'une ligne de données
    public static Resource createStartCardFromLine(String[] arrayLine, ArrayList<Position> cornerpositions) {
        ArrayList<Corner> cornersRecto = new ArrayList<>();
        ArrayList<Corner> cornersVerso = new ArrayList<>();
        HashMap<String,Integer> centerType = new HashMap<>();

        // Traitement des coins recto
        for (int i = 0; i < 4; i++) {
            if (arrayLine[2 + i].equals("Invisible")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), false));
            } else if (arrayLine[2 + i].equals("Empty")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), true));
            } else if (arrayLine[2 + i].contains(":")) {
                var mot = arrayLine[2 + i].split(":");
                var corner = new Corner(mot[1], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            } else {
                var corner = new Corner(arrayLine[2 + i], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            }
        }

        // Traitement des coins verso
        for (int i = 0; i < 4; i++) {
            if (arrayLine[7 + i].equals("Invisible")) {
                cornersVerso.add(new Corner(cornerpositions.get(i), false));
            } else if (arrayLine[7 + i].equals("Empty")) {
                cornersVerso.add(new Corner(cornerpositions.get(i), true));
            } else if (arrayLine[7 + i].contains(":")) {
                var mot = arrayLine[7 + i].split(":");
                var corner = new Corner(mot[1], cornerpositions.get(i), true);
                cornersVerso.add(corner);
            } else {
                var corner = new Corner(arrayLine[7 + i], cornerpositions.get(i), true);
                cornersVerso.add(corner);
            }
        }

        // Traitement des ressources centrales
        for (int i = 12; i < arrayLine.length; i++) {
            var mot = arrayLine[i].split(":");
            centerType.put(mot[1], centerType.getOrDefault(arrayLine[i], 0) + 1);
        }

        return new Resource(cornersRecto, "Start", new Resource(cornersVerso, "Start", centerType));
    }

    // Crée une carte ressource à partir d'une ligne de données
    public static Resource createResourceFromLine(String[] arrayLine, ArrayList<Position> cornerpositions) {
        ArrayList<Corner> cornersRecto = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            if (arrayLine[2 + i].equals("Invisible")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), false));
            } else if (arrayLine[2 + i].equals("Empty")) {
                cornersRecto.add(new Corner(cornerpositions.get(i), true));
            } else if (arrayLine[2 + i].contains(":")) {
                var mot = arrayLine[2 + i].split(":");
                var corner = new Corner(mot[1], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            } else {
                var corner = new Corner(arrayLine[2 + i], cornerpositions.get(i), true);
                cornersRecto.add(corner);
            }
        }
        String type = arrayLine[7];
        if (!arrayLine[9].equals("None")) {
            var mot = arrayLine[9].split(":");
            String score = mot[1];
            return new Resource(cornersRecto, type, Integer.parseInt(score));
        }
        return new Resource(cornersRecto, type, 0);
    }

    // Vérifie si les conditions de placement sont acceptées
    public boolean requirementAccepted(Board board) {
        return true;
    }

    // Retourne le type de la carte
    @Override
    public String type() {
        return type;
    }

    // Retourne la carte verso
    public Resource verso() {
        return verso;
    }

    // Indique si c'est une carte verso
    public boolean isVerso() {
        return isVerso;
    }

    // Retourne les points de la carte
    public int point() {
        return point;
    }
}
