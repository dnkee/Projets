package fr.but.sae.view;

import fr.but.sae.model.card.Card;
import fr.but.sae.model.card.Gilding;
import fr.but.sae.model.card.Objective;
import fr.but.sae.model.card.Resource;
import fr.but.sae.model.*;
import fr.umlv.zen5.ApplicationContext;

import java.awt.*;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.HashMap;

public record GameView(int height, int width, GameData data, Position boardRealPosition, Position boardSize) {



	private void drawBoard(Graphics2D graphics, GameData data, Board board){
		for (Card c : board.board()){
			if (!c.isResource()){
				drawGilding(graphics, data,(Gilding)c, 0,0);
			}
			else
				drawResource(graphics,data,(Resource)c, 0, 0 );
		}
	}


	private void drawChoiceObjective (Graphics2D graphics, GameData data ){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Okaso",4,40));
		graphics.drawString("Choissisez votre  carte objectif !",width/2-300,height/2-200);
		graphics.setColor(Color.YELLOW);
		var x = width/2 - 100;
		var y = height/2+100;

		for (int i=0;i<2;i++){
			drawObjective(graphics,data,data.reserve().getObjective(data.objectivesSelection().get(i)),x,y);
			x+=150;
		}
	}
	private void drawPattern(int x, int y, HashMap<Position,String> pattern, Graphics2D graphics){
		for(Position p : pattern.keySet()){
			if(pattern.get(p).equals("Fungi")) graphics.setColor(Color.RED);
			if(pattern.get(p).equals("Insect")) graphics.setColor(Color.MAGENTA);
			if(pattern.get(p).equals("Animal")) graphics.setColor(Color.BLUE);
			if(pattern.get(p).equals("Plant")) graphics.setColor(Color.GREEN);
			graphics.fill(new Rectangle2D.Float(x+25+p.x()*8, y+27+p.y()*4, 10, 6));
			graphics.setColor(Color.BLACK);
			graphics.draw(new Rectangle2D.Float(x+25+p.x()*8, y+27+p.y()*4, 10, 6));

		}
	}
	private void drawObjective(Graphics2D graphics, GameData data, Objective card, int x, int y){
		if(card.isPattern()){
			graphics.setColor(new Color(177, 151, 116));
			graphics.fill(new Rectangle2D.Float(x, y, 100, 60));
			drawPattern(x,y,card.pattern(),graphics);
			String score=card.score()+"";
			graphics.setColor(Color.WHITE);
			graphics.fill(new Rectangle2D.Float(x+70, y+20,20 , 20));
			graphics.setColor(Color.BLACK);
			graphics.setFont(new Font("Arial",1,20));
			graphics.drawString(score,x+74,y+38);
		}
		else{
			graphics.setColor(new Color(177, 151, 116));
			graphics.fill(new Rectangle2D.Float(x, y, 100, 60));
			drawRequirementObjective(graphics,data,card,x,y);

		}
	}


	private void drawRequirementObjective(Graphics2D graphics, GameData data, Objective card, int x, int y){
		int sum = 0;


		graphics.setColor(Color.WHITE);
		graphics.fill(new Rectangle2D.Float(x+30, y, 30, 10));
		graphics.setColor(Color.BLACK);
		String z=card.score()+"";
		graphics.setFont(new Font("Arial",1,10));
		graphics.drawString(z,x+43,y+9);

		for (int value : card.artefactList().values()) {
			sum += value;
		}
		if (sum==2) {
			graphics.setColor(Color.WHITE);
			int a = x + 25;
			int b = y + 25;
			for (int i = 0; i < 2; i++) {
				graphics.fill(new Rectangle2D.Float(a, b, 20, 20));
				a += 25;
			}
			graphics.setFont(new Font("Arial",1,12));
			graphics.setColor(Color.BLACK);
			for (String s:  card.artefactList().keySet()){
				for(int i =0; i<card.artefactList().get(s);i++){
					graphics.setColor(Color.BLACK);
					if (s.equals("Inkwell") || s.equals("Quill") || s.equals("Manuscript")) graphics.setColor(Color.RED);
					graphics.drawString(s.substring(0,1),a-44,b+15);
				a+=25;}
			}

			}
		if (sum==3){
			graphics.setColor(Color.WHITE);
			int a =x+15;
			int b =y+25;
			for (int i =0; i<3;i++){

				graphics.fill(new Rectangle2D.Float(a,b,20,20));

				a+=25;
			}
			graphics.setFont(new Font("Arial",1,12));
			graphics.setColor(Color.BLACK);
			for (String s:  card.artefactList().keySet()){

					for(int i =0; i<card.artefactList().get(s);i++){
						graphics.setColor(Color.BLACK);
						if (s.equals("Inkwell") || s.equals("Quill") || s.equals("Manuscript")) graphics.setColor(Color.RED);
						graphics.drawString(s.substring(0,1),a-69,b+15);
						a+=25;
					}

				}
			}
		}



	private void drawResource(Graphics2D graphics, GameData data, Resource card, int x, int y) {

		int xCard;
		int yCard;
		if(card.position()!=null){
			Position pos= data.cardPositionToRealPosition(card.position(),this);
			xCard=pos.x()+x;
			yCard=pos.y()+y;
		}
		else{
			xCard=x;
			yCard=y;
		}
		graphics.setColor(new Color(232, 220, 202));
		graphics.fill(new Rectangle2D.Float(xCard, yCard, 100, 60));

		if (card.type().equals("Animal")) graphics.setColor(Color.BLUE);
		else if (card.type().equals("Insect")) graphics.setColor(Color.MAGENTA);
		else if (card.type().equals("Plant")) graphics.setColor(Color.GREEN);
		else if (card.type().equals("Fungi")) graphics.setColor(Color.RED);
		else graphics.setColor(Color.getHSBColor(254,254,226));
		graphics.fill(new Rectangle2D.Float(xCard, yCard, 100, 60));
		for (Corner c : card.cornerlist()){
			drawCorner(graphics,data,c,xCard,yCard);
		}
		if(card.point()>0){
			drawCardPoint(graphics,card,xCard,yCard);
		}
		if (card.isVerso()){
			drawResourceCenter(graphics,card, xCard, yCard);

		}

	}
	private void drawCardPoint( Graphics2D graphics, Card card,int xCard,int yCard){
		graphics.setColor(Color.WHITE);
		graphics.fill(new Rectangle2D.Float(xCard+30, yCard, 40, 10));
		graphics.setColor(Color.BLACK);
		String z=card.point()+"";
		graphics.setFont(new Font("Arial",1,10));
		graphics.drawString(z,xCard+57,yCard+9);

	}
	private void drawResourceCenter(Graphics2D graphics,Resource card,int x,int y){
		var z ="";
		var y2=0;
		var y2c=0;
		var compteur =1;
		if ( card.isStartCard()){
			var keys= card.centerResourcesStartCard().keySet();
			var numberOfType = 0;
			for (String s : keys){
				numberOfType+=card.centerResourcesStartCard().get(s);
			}
			for ( String s : keys){
				if (s.equals("Animal")) z= "A";
				else if (s.equals("Fungi")) z= "F";
				else if (s.equals("Plant")) z =" P";
				else if (s.equals("Insect")) z =" I";
				if (compteur==1){
					if (numberOfType==1 ) {
						y2=35;
						y2c=23;
					}
					if (numberOfType==2){
						y2=21;
						y2c=9;
					}
					if (numberOfType==3)  {
						y2= 15;
						y2c=3;
					}
					if (numberOfType==4)  {
						y2= 15;
						y2c=3;
					}
					if (numberOfType==5)  {
						y2= 15;
						y2c=3;
					}
					compteur++;
				}
				for (int i = 1 ; i<= card.centerResourcesStartCard().get(s);i++){
					graphics.setColor(Color.WHITE);
					graphics.fill(new Rectangle2D.Float(x+42, y+y2c, 15, 15));
					graphics.setColor(Color.BLACK);
					graphics.drawString(z,x+45,y+y2);
					if (numberOfType==5) {
						y2+=20;
						y2c+=20;
					}
					if (numberOfType==4) {
						y2+=20;
						y2c+=20;
					}

					if (numberOfType==3) {
						y2+=20;
						y2c+=20;
					}
					if (numberOfType==2){
						y2+=24;
						y2c+=24;
					}
				}
			}
		}
		else {
			if (card.type().equals("Animal")) z= "A";
			else if (card.type().equals("Fungi")) z= "F";
			else if (card.type().equals("Plant")) z =" P";
			else if (card.type().equals("Insect")) z =" I";
			graphics.setColor(Color.WHITE);
			graphics.fill(new Rectangle2D.Float(x+42, y+22, 15, 15));
			graphics.setColor(Color.BLACK);
			graphics.drawString(z,x+45,y+34);
		}
	}


	private void drawGilding(Graphics2D graphics, GameData data, Gilding card, int x, int y){
		int xCard;
		int yCard;
		if(card.position()!=null){
			Position pos= data.cardPositionToRealPosition(card.position(),this);
			xCard=pos.x()+x;
			yCard=pos.y()+y;
		}
		else{
			xCard=x;
			yCard=y;
		}
		if (card.type().equals("Animal")) graphics.setColor(Color.BLUE);
		else if (card.type().equals("Insect")) graphics.setColor(Color.MAGENTA);
		else if (card.type().equals("Plant")) graphics.setColor(Color.GREEN);
		else if (card.type().equals("Fungi")) graphics.setColor(Color.RED);
		graphics.fill(new Rectangle2D.Float(xCard, yCard, 100, 60));
		drawCardPoint(graphics,card,xCard,yCard);
		drawCondition( graphics,data,card, xCard, yCard);
		drawRequirement(graphics,data,card,xCard,yCard);

		for (Corner c : card.cornerlist()){
			drawCorner(graphics,data,c,xCard,yCard);
		}



	}


	private void drawCondition(Graphics2D graphics, GameData data, Gilding card, int x, int y){
		var z ="";
		if (card.condition().equals("C")) z= "C";
		else if (card.condition().equals("D")) z= "D";
		else if (card.condition().equals("I")) z =" I";
		else if (card.condition().equals("M")) z =" M";
		else if (card.condition().equals("Q")) z =" Q";
		graphics.setFont(new Font("Arial",1,10));
		graphics.drawString(z,x+32,y+9);
		graphics.setColor(Color.BLACK);
		graphics.fill(new Rectangle2D.Float(x+49, y, 2, 10));





	}


	private void drawRequirement(Graphics2D graphics, GameData data, Gilding card, int x, int y){
		var z ="";
		var y2=0;
		var y2c=0;
		var compteur =1;

		var keys= card.requirement().keySet();
		var numberOfType = 0;
		for (String s : keys){
			numberOfType+=card.requirement().get(s);
		}
		for ( String s : keys){
			if (s.equals("Animal")) z= "A";
			else if (s.equals("Fungi")) z= "F";
			else if (s.equals("Plant")) z =" P";
			else if (s.equals("Insect")) z =" I";
			if (compteur==1){
				if (numberOfType==1 ) {
					y2=42;
					y2c=60;
				}
				if (numberOfType==2){
					y2=30;
					y2c=42;
				}
				if (numberOfType==3)  {
					y2= 30;
					y2c=26;
				}
				if (numberOfType==4)  {
					y2= 26;
					y2c=22;
				}
				if (numberOfType==5)  {
					y2= 26;
					y2c=22;
				}
				compteur++;
			}
			for (int i = 1 ; i<= card.requirement().get(s);i++){
				graphics.setColor(Color.WHITE);
				graphics.fill(new Rectangle2D.Float(x+y2c, y+45, 15, 15));
				graphics.setColor(Color.BLACK);
				graphics.drawString(z,x+y2,y+57);
				if (numberOfType==3) {
					y2+=15;
					y2c+=15;
				}
				if (numberOfType==2){
					y2+=24;
					y2c+=24;
				}
				if (numberOfType==4){
					y2+=14;
					y2c+=14;
				}
				if (numberOfType==5){
					y2+=10;
					y2c+=10;
				}


			}
		}
	}




	private void drawCorner(Graphics2D graphics, GameData data, Corner corner, int xCard, int yCard){
		if (corner.existence()){
			var x =0;
			var y =0;
			if(corner.position().x()==-1 && corner.position().y()==-1 ){
				x =xCard;
				y =yCard;
			}
			if(corner.position().x()==-1 && corner.position().y()==1 ){
				x =xCard;
				y =yCard+40;
			}
			if(corner.position().x()==1 && corner.position().y()==-1 ){
				x =xCard+80;
				y =yCard;
			}
			if (corner.position().x()==1 && corner.position().y()==1 ){
				x =xCard+80;
				y =yCard+40;
			}
			graphics.setFont(new Font("Arial",1,12));
			graphics.setColor(Color.BLACK);
			graphics.fill(new Rectangle2D.Float(x, y, 20, 20));
			drawCornerType(graphics,  data,corner, x, y);
		}

	}
	private void drawCornerType(Graphics2D graphics, GameData data, Corner corner, int xCard, int yCard){
		var z ="";
		graphics.setColor(Color.WHITE);
		if (corner.specie().equals("Animal"))z= "A";
		else if (corner.specie().equals("Fungi")) z= "F";
		else if (corner.specie().equals("Plant")) z= "P";
		else if (corner.specie().equals("Insect")) z= "I";

		else if (corner.specie().equals("Inkwell")) {z= "I";
			graphics.setColor(Color.RED);
		}
		else if (corner.specie().equals("Manuscript")) {z= "M";
			graphics.setColor(Color.RED);
		}
		else if (corner.specie().equals("Quill")) {
			z= "Q";
			graphics.setColor(Color.RED);
		}
		graphics.drawString(z,xCard+5,yCard+15);
	}

	private void drawReserve(Graphics2D graphics, GameData data){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Arial",1,16));
		graphics.drawString("Dorrure",width-100,55);
		graphics.drawString("Ressource",width-230,55);

		if(data.reserve().size().get("GoldCard")>=3)
			drawResource(graphics,data,data.reserve().get(2).verso(),width-120,70);
		if (data.reserve().size().get("GoldCard")>=2)
			drawGilding(graphics,data,(Gilding) data.reserve().get(1),width-120,150);
		if (data.reserve().size().get("GoldCard")>0)
			drawGilding(graphics,data,(Gilding) data.reserve().get(0),width-120,230);
		if(data.reserve().size().get("ResourceCard")>=3)
			drawResource(graphics,data,data.reserve().get(5).verso(),width-240,70);
		if(data.reserve().size().get("ResourceCard")>=2)
			drawResource(graphics,data,(Resource) data.reserve().get(4),width-240,150);
		if(data.reserve().size().get("ResourceCard")>0)
			drawResource(graphics,data,(Resource) data.reserve().get(3),width-240,230);



	}
	private void drawChoiceStartCard (Graphics2D graphics, GameData data ){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Okaso",4,40));
		graphics.drawString("Choissisez votre carte de depart !",width/2-300,height/2-200);
		graphics.setColor(Color.YELLOW);
		var x = -200;
		var y = -70;
		int numberPlayer=data.reserve().size().get("StarterCard");
		for (int i=0;i<numberPlayer;i++){
			drawResource( graphics, data,(Resource) data.reserve().get(6+i),width/2+x,height/2+y);
			x+=150;
			if (i==2){
				y=10;
				x=-200;
			}
		}
	}
	private void drawDeck(Graphics2D graphics, GameData data, Deck deck, int selected){


		int x=(width/2)-175;
		int y=height-100;
		int i=1;
		for(Card c:deck.cards()){
			if(i==selected){
				if(c.requirementAccepted(data.currentPlayer().board())||data.isVerso()){
					graphics.setColor(Color.WHITE);
				}
				else{
					graphics.setColor(Color.RED);
					graphics.drawString("You can't place this card",x,y-20);
				}
				graphics.fill(new Rectangle2D.Float(x-2, y-2,104,64));
			}

			if(i==selected && data.isVerso()){
				drawResource(graphics,data,c.verso(),x,y);
			}
			else {
				if (c.isResource()) {
					drawResource(graphics, data, (Resource) c, x, y);
				} else {
					drawGilding(graphics, data, (Gilding) c, x, y);
				}
			}

			if(i==1){
				graphics.setFont(new Font("Arial",1,16));
				graphics.setColor(Color.BLACK);
				graphics.drawString("A",x+40,y+75);
			}
			if(i==2){
				graphics.setFont(new Font("Arial",1,16));
				graphics.setColor(Color.BLACK);
				graphics.drawString("Z",x+40,y+75);
			}
			if(i==3){
				graphics.setFont(new Font("Arial",1,16));
				graphics.setColor(Color.BLACK);
				graphics.drawString("E",x+40,y+75);
			}
			i++;
			x+=125;
		}
		if(i==3){
			graphics.setColor(Color.WHITE);
			graphics.fill(new Rectangle2D.Float(x, y,100,60));
			graphics.setColor(Color.BLACK);
			graphics.setFont(new Font("Arial",1,16));
			graphics.drawString("EMPTY",x+20,y+40);
			x+=125;
		}
		if(selected!=-0){
			graphics.setColor(Color.BLACK);
			graphics.setFont(new Font("Arial",1,16));
			graphics.drawString("Press R to flip the card",x+20,y+40);}

	}


	private void drawScore(Graphics2D graphics, GameData data, int score){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Arial",1,30));
		var x ="SCORE : "+score;
		graphics.drawString(x,(width/2)-50,40);
	}
	private void drawPlayer(Graphics2D graphics, GameData data){
		var player=data.currentPlayer();
		drawBoard(graphics,data,player.board());
		if(data.selectedCard()!=0 && (data.gameState().equals("play")||data.gameState().equals("placingstartcard"))){
			drawPlayablePosition(graphics,data,data.currentPlayer().board());
		}
		drawBackground(graphics,data);
		drawDeck(graphics,data,player.deck(),data.selectedCard());
		drawScore(graphics,data,player.score());
		drawNumberPlayer(graphics,data);
	}

	private void drawObjectiveCards(Graphics2D graphics,GameData data){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Okaso",4,10));
		graphics.drawString("Objectif Commun :",width-240,height-270);
		graphics.drawString("Objectif Personnel :",width-120,height-270);
		drawObjective(graphics,data,data.commonObjective(),width-240,height-260);
		drawObjective(graphics,data,data.currentPlayer().personalObjective(),width-120,height-260);
	}
	private void drawBackground(Graphics2D graphics, GameData data){
		graphics.setColor(new Color(232, 220, 202));
		var outerRect=new Rectangle2D.Float(0,0,width,height);
		var innerRect=new Rectangle2D.Float(boardRealPosition.x(), boardRealPosition.y(),boardSize.x(),boardSize.y());

		Area area = new Area(outerRect);
		area.subtract(new Area(innerRect));

		graphics.fill(area);
		graphics.setColor(Color.BLACK);
		graphics.setStroke(new BasicStroke(2.0f));
		graphics.draw(innerRect);


	}

	private void drawPlayablePosition(Graphics2D graphics, GameData data, Board board){
		graphics.setColor(Color.LIGHT_GRAY);
		for (Position p : board.playablePlace()){
			Position posi = data.cardPositionToRealPosition(p,this);
			graphics.fill(new Rectangle2D.Float(posi.x(),posi.y(),100,60));
		}
	}

	private void drawNumberPlayer(Graphics2D graphics, GameData data){
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Arial",1,30));
		var x ="A TOI DE JOUER : "+data.currentPlayer().name();
		graphics.drawString(x,10,30);

	}


	private void drawMenu(Graphics2D graphics, GameData data){
		graphics.setFont(new Font("Arial",1,45));
		graphics.setColor(Color.BLACK);
		graphics.drawString("CODEX NATURALIS",(width/2)-215,60);
		graphics.setFont(new Font("Arial",1,25));
		graphics.drawString("by Ethan & Dylan",(width/2)+50,90);
		graphics.setFont(new Font("Arial",1,30));
		String[] buttonArray={"Solo","Multiplayer","Quit"};
		int yText=260;
		int yButton=200;
		for(String button:buttonArray){
			graphics.setColor(Color.white);
			graphics.fill(new RoundRectangle2D.Float((width/2)-200,yButton,400,100,50,50));
			graphics.setColor(Color.BLACK);
			graphics.drawString(button,(width/2)-50,yText);
			yText+=200;
			yButton+=200;
		}
	}
	private void drawMenuMulti(Graphics2D graphics, GameData data){
		graphics.setFont(new Font("Arial",1,45));
		var x ="A COMBIEN JOUEZ VOUS";
		graphics.setColor(Color.BLACK);
		graphics.drawString(x,(width/2)-270,60);
		graphics.setFont(new Font("Arial",1,25));
		graphics.setColor(Color.red);
		graphics.fill(new RoundRectangle2D.Float(100,100,100,100,50,50));
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Arial",1,80));
		graphics.drawString("X",124,180);
		graphics.setFont(new Font("Arial",1,25));
		int y=100;
		for(int i=2;i<=5;i++){
			graphics.setColor(Color.white);
			graphics.fill(new RoundRectangle2D.Float((width/2)-50,y,100,100,50,50));
			graphics.setColor(Color.BLACK);
			graphics.drawString(i+"",(width/2)-5,y+60);
			y+=200;
		}

	}


	private void drawEndGame(Graphics2D graphics, GameData data) {
		graphics.setFont(new Font("Arial",1,45));
		graphics.setColor(Color.BLACK);
		graphics.drawString("Le vainqueur est " + data.winner().name() + " avec " + data.endGame().get(data.winner()) + " points", (width / 2) - 350, 60);
		graphics.setFont(new Font("Arial",1,30));
		int y=300;
		for (Player p : data().players()){
			if (p!=data.winner()){
				graphics.drawString(p.name() + "fini la partie avec " + data.endGame().get(p) + "points", (width / 2) - 230, y);
				y+=150;
			}

		}

	}


	private void draw(Graphics2D graphics, GameData data){
		graphics.clearRect(0,0,width,height);

		if(data.gameState().equals("startgame")){
			drawMenu(graphics, data);
		}
		else if(data.gameState().equals("multiplayerMenu")){
			drawMenuMulti(graphics, data);
		}
		else if(data.gameState().equals("startpick")){
			drawChoiceStartCard(graphics, data);
			drawNumberPlayer(graphics, data);
		}
		else if(data.gameState().equals("startpick2")){
			drawChoiceObjective(graphics, data);
			drawNumberPlayer(graphics, data);
		}
		else if(data.gameState().equals("endgame")){
			drawEndGame(graphics, data);
		}


		else{
			drawPlayer(graphics, data);
			drawObjectiveCards(graphics,data);
			drawReserve(graphics, data);

		}
	}


	public static void draw(ApplicationContext context, GameView view, GameData data) {
		context.renderFrame(graphics -> view.draw(graphics, data));
	}
}
