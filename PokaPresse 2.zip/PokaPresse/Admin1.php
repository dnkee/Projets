<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Admin"){
  $id=$_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Admin1.css" />
    <title>Document</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
  </head>
  <body>

  <?php
  include("header.inc.html");
  ?>
    <div class="navchoice">
      <a href="Admin1.php" id="left"> <span>Administrer</span></a>
      <a href="Admin3.php" id="right"> <span>Visualiser</span></a>
    </div>
    <div class="conteneur">
        <form action="Admin2.php" method="POST">
    <ul>
          <?php     
          include "connexion.inc.php";
       $result2=$cnx->query("SELECT nom,prenom,metier,adressemail  from pokapresse.participant;");
        while($ligne = $result2->fetch(PDO::FETCH_OBJ)){   
            ?>
        <li>
          <div class="a"><span>Nom :</span name="azz" >  <?php echo $ligne->nom?></div>
          <div class="b"><span>Prenom :</span> <?php echo $ligne->prenom?></div>
          <div class="c"><span>Metier :</span> <?php echo $ligne->metier?></div>
          <div class="d"><span>Mail :</span> <?php echo $ligne->adressemail?></div>
         
          <input  type="submit"
           value="<?php echo $ligne->nom ?>" 
           id="sub"
           name="nom"
           /><i class="fa-solid fa-rotate"></i>
        </li>
      <?php } ?>
      </ul>
      </form>
    </div>
  </body>
</html>
<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>
