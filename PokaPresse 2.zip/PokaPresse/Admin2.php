<?php

session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Admin"){
  $id=$_SESSION['id'];
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Admin2.css" />

    <title>Document</title>
  </head>
  <body>
        <?php
    
  include("header.inc.html");
  ?>
    <div class="navchoice">

  
      <a href="Admin1.php" id="left"> <span>Administrer</span></a>
      <a href="Admin3.php" id="right"> <span>Visualiser</span></a>
    </div>
    <h1 id="head1">Changez le mot de passe</h1>
    <div class="center">
      <form method="POST"><div class="top-center">
          <input type="text" id="textarea" name="mdp"/>
          <label for="textarea"></label>
        </div>
        <div class="bottom-center">
        <input type="hidden"  value="<?php echo $_POST["nom"];;?>"name="cache"/>
        <input type="reset" id="reset" value="Annuler" />
          
          <input type="submit" id="submit" value="Confirmer" />
        </div>
      </form>
    </div>
    <?php     
          include "connexion.inc.php";
          if(isset($_POST["mdp"])&& isset($_POST["cache"])){
          $cnx->beginTransaction();
          $mdp=$_POST["mdp"];
          $nom = $_POST["cache"];
          $nmdp=md5($mdp);
          $requete = "update pokapresse.participant set mdp='$nmdp' WHERE nom='$nom' ;";
          $result2=$cnx->query($requete);
          $cnx->commit();
       if($result2){
        header("location: Admin1.php");
      
       }  }?>
  </body>
</html>

<?php }else{
  
  header("location: Connexion.php");} } else{
  
  header("location: Connexion.php");}?>
