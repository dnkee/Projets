<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Admin"){
  $id=$_SESSION['id'];
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Admin3.css">
    <title>Document</title>
  </head>
  <body>
    
    <?php
    include "header.inc.html";
    ?>

<div class="navchoice">

  
<a href="Admin1.php" id="left"> <span>Administrer</span></a>
<a href="Admin3.php" id="right"> <span>Visualiser</span></a>
</div>
 

      <div class="barre1"></div>
    <h2>En ligne</h2>
    <div class="barre2"></div>

    <ul><form action="Admin4.php" method="POST">
    <?php  
    	include "connexion.inc.php";
        $result=$cnx->query("SELECT nummag  as nm FROM pokapresse.numero_magazine WHERE version IS NOT null;;")  ; 
        while($ligne = $result->fetch(PDO::FETCH_OBJ)){  
            ?>
      
        <li>
          <input class="numMag" type="submit"
           value="  <?php echo $ligne->nm ?>" 
           id="<?php echo $ligne->nm ?>"
           name="Mag"
           />
           
        </li>

   
            <?php } 
    ?>
       </form>
        </ul>
    <div class="barre1"></div>
    <h2>Attribuable</h2>
    <div class="barre2"></div>

  
    <div class=center>
    <ul>  
    <?php  
    	include "connexion.inc.php";
        $result=$cnx->query("SELECT titre , date_mise_en_ligne ,contenu
        FROM pokapresse.article ;")  ; 
        while($ligne = $result->fetch(PDO::FETCH_OBJ)){  
            ?>
          <li>
            <div class="b">
              <span>Titre :</span>                
              <?php echo $ligne->titre ?>
            </div>
            <div class="c">
              <span>Date :</span>
              <?php echo $ligne->date_mise_en_ligne ?>
            </div>
            <a href=<?php echo $ligne->contenu ?> ><i class="fa-regular fa-circle-down"></i></a>
          </li>
   
            <?php } 
    ?>
    </ul>
    </div>


  </body>
</html>
<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>