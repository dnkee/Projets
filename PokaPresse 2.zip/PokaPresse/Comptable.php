
<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Comptable"){
  $id=$_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Comptable.css" />

    <title>Document</title>
  </head>
  <body>
    <?php 
      include("connexion.inc.php");
    include("header.inc.html"); ?>
    <div class="conteneur">
    <form method="POST">
      <ul class="top">

        <li>
          <select name="NumMag">
            <option value="num" selected>NumMag</option>
            <?php 
				
				  $result=$cnx->query("SELECT DISTINCT(nummag) FROM  pokapresse.vendre");
				  while( $ligne = $result->fetch(PDO::FETCH_OBJ)){
					echo "<option value".$ligne->nummag.">".$ligne->nummag."</option>";
				}
				$result->closeCursor();
				  ?>
 
          </select>
        </li>
        <li>
          <select name="Quantité">
            <option value="quan" selected>Quantité</option>
            <option value="quantite_vendu Desc">Descendant</option>
            <option value="quantite_vendu Asc">Ascendant</option>
          </select>
        </li>
        <li>
          <select name="Date">
            <option value="date" selected>Date</option>
            <option value="tout_les_mois Desc">Descendant</option>
            <option value="tout_les_mois ASC">Ascendant</option>
          </select>
        </li>
        <li>
          
        <select name="Canal">
          
            <option value="can" selected>Canal</option>
            <?php 
				
        $result=$cnx->query("SELECT DISTINCT(nomc),vendre.num_canal FROM  pokapresse.vendre,pokapresse.canal_distribution where canal_distribution.num_canal = vendre.num_canal ;");
        while( $ligne = $result->fetch(PDO::FETCH_OBJ)){
        echo "<option value =".$ligne->num_canal.">".$ligne->nomc."</option>";
      }
      $result->closeCursor();
        ?>

          </select>
        </li>
        <li>
          <select name="Pays">
            <option value="pays" selected>Pays</option>
			<?php
            $result=$cnx->query("SELECT DISTINCT(libelle),numdep FROM  pokapresse.vendre,pokapresse.region WHERE numdep=region.code_p ; ");
        while( $ligne = $result->fetch(PDO::FETCH_OBJ)){
        echo "<option value =".$ligne->numdep.">".$ligne->libelle."</option>";
      }
      $result->closeCursor();
        ?>
          </select>
        </li>
        </ul>
      <span id=sub>  <input type="submit" id="submit" name="submit"></span>
    </form>
      <ul class="bottom">
        <?php


if((isset($_POST["Quantité"])
&& isset($_POST["Date"]) 
&& isset($_POST["Canal"])
&& isset($_POST["Pays"])
&& isset($_POST["NumMag"]))){
    $nm=$_POST["NumMag"];
    $q=$_POST["Quantité"];
    $da=$_POST["Date"];
    $c=$_POST["Canal"];
    $pa=$_POST["Pays"];
    
    if($nm="num"){

      if ($q!="quan"){
        $req="SELECT nummag, quantite_vendu, tout_les_mois, nomc, libelle 
        FROM pokapresse.vendre, pokapresse.canal_distribution, pokapresse.region 
        WHERE canal_distribution.num_canal = vendre.num_canal ORDER BY $q ;";
      }
      if ($da!="date"){
        $req="SELECT nummag, quantite_vendu, tout_les_mois, nomc, libelle 
        FROM pokapresse.vendre, pokapresse.canal_distribution, pokapresse.region 
        WHERE canal_distribution.num_canal = vendre.num_canal ORDER BY $da ;";
      }         
      if($da!="date" && $q!="quan"){
       $req="SELECT nummag, quantite_vendu, tout_les_mois, nomc, libelle 
        FROM pokapresse.vendre, pokapresse.canal_distribution, pokapresse.region 
        WHERE canal_distribution.num_canal = vendre.num_canal ORDER BY $q, $da ;";
        }    
      }
      else{
        $req="SELECT nummag, quantite_vendu, tout_les_mois, nomc, libelle 
        FROM pokapresse.vendre, pokapresse.canal_distribution, pokapresse.region 
        WHERE canal_distribution.num_canal = vendre.num_canal 
        AND numdep = code_p
        AND nummag = $nm 
        AND numdep = '$pa' 
        AND vendre.num_canal = $c
        ORDER BY $q, $da ;";
    
      }
    $result=$cnx->query($req);
    if($result){
    while( $ligne = $result->fetch(PDO::FETCH_OBJ)){
     ?>
  <li>
  <div class="content"><span><?php  echo $ligne->nummag ?></span></div>
  <div class="content"><span><?php  echo $ligne->quantite_vendu ?></span></div>
  <div class="content"><span><?php  echo $ligne->tout_les_mois?></span></div>
  <div class="content"><span><?php  echo $ligne->nomc?></span></div>
  <div class="content"><span><?php  echo $ligne->libelle ?></span></div>
</li>

  
<?php  }}

else{
  header("location: Comptable.php");

}}
else{
        $result=$cnx->query("SELECT nummag,quantite_vendu,tout_les_mois,nomc,libelle FROM pokapresse.vendre , pokapresse.canal_distribution, pokapresse.region WHERE  canal_distribution.num_canal = vendre.num_canal and numdep=code_p");
        while( $ligne = $result->fetch(PDO::FETCH_OBJ)){
         ?>
      <li>
        
      <div class="content"><span><?php  echo $ligne->nummag ?></span></div>
      <div class="content"><span><?php  echo $ligne->quantite_vendu ?></span></div>
      <div class="content"><span><?php  echo $ligne->tout_les_mois?></span></div>
      <div class="content"><span><?php  echo $ligne->nomc?></span></div>
      <div class="content"><span><?php  echo $ligne->libelle ?></span></div>
     
      
    </li>
      
      
     
      
    <?php  }
      $result->closeCursor();
    }
        ?>
      
     
      </ul>
    </div>
  </body>
</html>
<?php }
else{
  
  header("location: Connexion.php");}

} else{
  
  header("location: Connexion.php");}?>
