<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Connexion.css" />
    <link rel="stylesheet" href="style/font.css" />
    <title>Document</title>
  </head>

  <body>
    <h1>Poka Presse</h1>
    <div class="conteneur">
      <form method="POST">
        <label for="id"></label>
        <input type="text" id="id" name=pseudo placeholder="Id en ligne" />
        <label for="mdp"></label>
        <input type="password" id="mdp" placeholder="Mot de passe" name="mdp"/>
        <input type="submit" id="submit" value="Connexion" />
      </form>
    </div>

    <?php 

if(isset($_POST["pseudo"])&&isset($_POST["mdp"])){
	$pseudo=$_POST["pseudo"];
    $mdp=$_POST["mdp"];
    $mdp=md5($mdp);


include("connexion.inc.php");
$req="SELECT * FROM pokapresse.participant WHERE prenom = '".$pseudo."' AND mdp = '".$mdp."';" ;
$result=$cnx->query($req);


if($ligne = $result->fetch(PDO::FETCH_OBJ)){
  $n=$ligne->metier;
  $_SESSION['id'] = $ligne->matricule;
	$_SESSION['login'] = $pseudo;
	$_SESSION['mdp'] = $mdp;
  $_SESSION["metier"]=$n;
  
  if($n=="Comptable"){
    header("location: Comptable.php");
  }
  if($n=="Maquettiste"){
    header("location: Maquettiste1.php");
  }
  if($n=="Pigiste"){
    header("location: Pigiste.php");
  }
  if($n=="Redacteur"){
    header("location: Redacteur1.php");
  }
  if($n=="Admin"){
    header("location: Admin1.php");
  }

$result->closeCursor();
}
else{
  echo "<div class=error>Login ou mot de passe incorrect</div>";
}
}
?>
</body>

 
</html>
