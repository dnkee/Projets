<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Maquettiste"){
  $id=$_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="Maquettiste1.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
  </head>
  <body>
    <?php 
    include("header.inc.html");
    ?>
    <div class="navchoice">
      <a href="Maquettiste1.php" id="left"> <span>Maquette</span></a>
      <a href="Maquettiste2.php" id="right"> <span>Articles</span></a>
    </div>
    </div>
    <div class="barre1"></div>
    <h2>Vos créations</h2>
    <div class="barre2"></div>
    <ul>
    <?php
    include "connexion.inc.php";
    $id = $_SESSION['id'];
    $result2=$cnx->query("SELECT maquette.version,date_version as annees , fichier_image from pokapresse.maquette, pokapresse.choisir,pokapresse.image where image.n_image = choisir.n_image and  maquette.version = choisir.version and maquette.matricule = $id;");
   while($ligne = $result2->fetch(PDO::FETCH_OBJ)){
    ?>
      <li>
        <img src="<?php echo $ligne->fichier_image ;?>" alt="" />
        <div class="info_bottom">
          <div class="infos_left">
            <span>Version: <?php echo  $ligne->version?></span>
            <div class="barre"></div>
            <span><?php echo $ligne->annees?></span>
          </div>
          <div class="infos_right">
            <a href=""><i class="fa-regular fa-circle-down"></i></a>
          </div>
        </div>
      </li>
      <?php  } ?>
    </ul>

    <div class="barre1"></div>
    <h2>Ajouter une maquette</h2>
    <div class="barre2"></div>
    <form method="POST">
      <div class="haut">



        <input type="text" id="img" name="image"  placeholder="Entrez un lien"/>
        <input type="file" id="fichier" accept=".pdf" name="fichier" />
        <label class="fich" for="fichier">
          <i class="fa-solid fa-file-import"></i>
          Séléctionner Maquette
        </label>
        </div>
        <div class="select">
        <select name="num">
    <option value="debut" selected> Choisissez un Num Mag</option>
    <?php 
    $req = "SELECT DISTINCT(numero_magazine.nummag) 
    FROM pokapresse.article, pokapresse.maquette, pokapresse.numero_magazine 
    WHERE maquette.matricule =$id
    AND pokapresse.numero_magazine.numMag = pokapresse.article.numMag 
    AND pokapresse.numero_magazine.version = pokapresse.maquette.version 
    AND mois IS NULL;";
    echo $req;
    $result = $cnx->query($req);
    while ($ligne = $result->fetch(PDO::FETCH_OBJ)) {
        echo "<option value='$ligne->nummag'>$ligne->nummag</option>";
    }
    $result->closeCursor();
    ?>
</select>
</div>
      </div>
      <div class="bas">
      
      
        
        <input type="reset" id="reset" value="Annuler" />
        <input type="submit" id="submit" value="Confirmer" name="add" />
       
      </div>
    </form>
  </body>

  
  <?php



if(isset($_POST["fichier"])&&isset($_POST["image"])){
  $date=date("d-m-Y");
  $image=$_POST["image"];
  $fichier=$_POST["fichier"];
  $num=$_POST["num"];
  $cnx->beginTransaction();
  
  if(isset($_POST["add"])){
   
    $req_____="SELECT version FROM pokapresse.numero_magazine WHERE nummag=$num";
    $res_____=$cnx->query($req_____);
    $ligne = $res_____->fetch(PDO::FETCH_OBJ);
    $version = $ligne->version;
    $req="INSERT INTO pokapresse.maquette values(default,'$date','$fichier',$id,$version) RETURNING version;" ;
      
      
      $req3="INSERT INTO pokapresse.image values(default,'$image') RETURNING n_image;";

      
      
      
      
      
      
      $result=$cnx->query($req);
      $result3=$cnx->query($req3);
   

      $num = $result->fetch();
      $n= $num["version"];
      $num3 = $result3->fetch();
      $n3=$num3["n_image"];

      $req2="INSERT INTO pokapresse.choisir values($n,$n3);";
      $result2=$cnx->query($req2);
     

      if($result!=false && $result2!=false && $result3!=false){
        $cnx->commit();
      }else{
        echo "<br>Erreur req1.";
      }
}

}

  ?>
</html>

<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>


