<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Maquettiste"){
  $id=$_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Maquettiste2.css" />
    <title>Document</title>
</head>
<body>
    <?php
    include("header.inc.html")
    ?>
    <div class="navchoice">
      <a href="Maquettiste1.php" id="left"> <span>Maquette</span></a>
      <a href="Maquettiste2.php" id="right"> <span>Article</span></a>
    </div>
    <div class="barre1"></div>
    <h2>Articles</h2>
    <div class="barre2"></div>
    <div class=center>
    <?php  
    	include "connexion.inc.php";
        $result=$cnx->query("SELECT titre , date_mise_en_ligne ,contenu,article.numMag as nm 
        FROM pokapresse.article , pokapresse.maquette , pokapresse.numero_magazine 
        WHERE maquette.matricule =$id
        and pokapresse.numero_magazine.numMag = pokapresse.article.numMag 
        and pokapresse.numero_magazine.version = pokapresse.maquette.version; ");
        $count=0;
        while($ligne = $result->fetch(PDO::FETCH_OBJ)){  
          if($count==0){
            $num=$ligne->nm;
            ?>
                <h3 class=titre>
                  <?php echo  "Num Mag : ".$ligne->nm; ?>
                </h3>
            <div class="barre"></div>
            <ul>
            <?php
            $count+=1; 
            }
          if($num!=$ligne->nm){
            ?></ul>
            <h3 class=titre>
              <?php echo "Num Mag : ".$ligne->nm; ?>
          </h3>
            <div class="barre"></div>
            <ul>
            <?php
            $num=$ligne->nm;
          }
          ?>
          <li>
            <div class="b">
              <span>Titre :</span>                
              <?php echo $ligne->titre ?>
            </div>
            <div class="c">
              <span>Date :</span>
              <?php echo $ligne->date_mise_en_ligne ?>
            </div>
            <a href=<?php echo $ligne->contenu ?> ><i class="fa-regular fa-circle-down"></i></a>
          </li>
   
            <?php } 
    ?>
    </ul>
    </div>
</body>
</html>
<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>