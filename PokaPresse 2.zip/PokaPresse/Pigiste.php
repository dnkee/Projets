<?php
session_start();



if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
    if($_SESSION['metier']=="Pigiste"){
      include("connexion.inc.php");
      $id=$_SESSION['id'];
      $cnx->beginTransaction();
    
      
     


if(isset($_POST["titre"])&& isset($_POST["number"])&& isset($_POST["file"])&& isset($_POST["chap"])){
  
  $titre=$_POST["titre"];
  $file=$_POST["file"];
  $chap=$_POST["chap"];
  $number=$_POST["number"];
  $date=date("d-m-Y");
  if(isset($_POST["add"])){
      $req="INSERT INTO pokapresse.article values('$titre','$chap','$file',$number,null,1,'$date',$id);";
      $result=$cnx->exec($req);
      if($result!=0){
        $cnx->commit();
       header('location: Pigiste.php');
      
       

       exit();
      }else{
        echo "<br>Erreur lors de l’ajout de votre loisir.";
       
      }
      
 
}
}

if(isset($_POST["titre"])){
  $titre=$_POST["titre"];
  if(isset($_POST["delete"])){
    $req2="DELETE FROM pokapresse.article WHERE titre = '$titre' ;";
    echo "delete";
    $result2=$cnx->exec($req2);
            if($result2!=0){
              $cnx->commit();
              header("location: Pigiste.php");
             
            }else{
              echo "<br>Erreur lors de la suppresion de votre loisir.";
            }
}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Pigiste.css" />
    <link rel="stylesheet" href="style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
  </head>
    
  <body>
<?php
    include "header.inc.html";?><div class="barre1"></div>
    <h2>Vos créations</h2>
    <div class="barre2"></div>
    <div class="conteneur-bar">
    <ul>  
<?php  
    include "connexion.inc.php";
       $result2=$cnx->query("SELECT titre, date_mise_en_ligne, contenu  from pokapresse.article where matricule = $id ;");
      while($ligne = $result2->fetch(PDO::FETCH_OBJ)){?><li>
            <div class="b">
              <span>Titre :</span><?php echo $ligne->titre?></div>
            <div class="c">
              <span>Date :</span>
              <?php echo $ligne->date_mise_en_ligne?>          
              </div>
            <a href=""><i class="fa-regular fa-circle-down"></i></a>
          </li>
   
<?php } 

    ?></ul>
    </div>
    
    
    <div class="barre1"></div>
    <h2>Ajouter un article</h2>
    <div class="barre2"></div>
    <form  method=POST>
      
    <div class="cont1">
        <label for="titre"></label>
        <input type="text" id="titre" placeholder="Titre :" name="titre" />
        <label for="nb"></label>
        <input type="number" id="nb" placeholder="Nbr feuillet :"  name="number"/>
        <input
          type="file"
          id="fichier"
          accept=".pdf,.txt,.doc,.docx"
          placeholder="Selectionner fichier :"
          name="file"
        />
        <label class="fich" for="fichier">
          &nbsp; &nbsp; &nbsp; Séléctionner un fichier
          <i class="fa-solid fa-file-import"></i
        ></label>
      </div>

      <div class="cont2">
        <label for="chap"></label>
        <input
          type="text"
          name="chap"
          id="chap"
          placeholder="Entrez le chapeau :"

        />
      </div>
      <div class="cont3">
        <input type="reset" id="reset" value="Annuler" />
        <input type="submit" id="supp" value="Supprimer" name="delete"/>
        <input type="submit"name="add" id="submit" value="Confirmer"  />
      </div>
    </form>
</body>
</html>
<?php   }

else{
  
  header("location: Connexion.php");
}

} 
  
  else{
  
  header("location: Connexion.php");
  
  
  }?>
