<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Redacteur"){
  $id=$_SESSION['id'];
  include("connexion.inc.php");
  $cnx->beginTransaction();
 
  if (isset($_POST["submit"])){		
    echo "SUB";
    $date=date("d-m-Y");
    $id=$_POST["Maquettiste"];
    echo $id;
    $req="INSERT INTO pokapresse.maquette values(default,'$date',null,'$id',null) RETURNING version ;";
    echo $req;
    $result = $cnx->query($req);
    $r = $result->fetch();
    $rs=$r["version"];
    $req2="INSERT INTO pokapresse.numero_magazine values(default,null,null,'$rs',4) RETURNING nummag;";
    $res = $cnx->query($req2);
    $z = $res->fetch();
    $nummag=$z["nummag"];
    $results = $cnx->query("SELECT * FROM pokapresse.article WHERE nummag IS NULL;");
    while ($ligne = $results->fetch(PDO::FETCH_OBJ)) {
        $titre = $ligne->titre;
        $nouveau_titre = str_replace(' ', '_', $titre);
        if (isset($_POST[$nouveau_titre])) {
            $k = $_POST[$nouveau_titre];
            $req3 = "UPDATE pokapresse.article SET nummag=$nummag WHERE titre='$k';";
            $res2 = $cnx->exec($req3);
            if ($res2) {

               
            }
        }
    }
    $cnx->commit();
  }        
  

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Redacteur1.css" />
    <title>Document</title>
  </head>
  <body>
    <?php 
    include("header.inc.html");
    include("connexion.inc.php");
    ?>
   <div class="navchoice">
      <a href="Redacteur1.php" id="left">
         <span>Attribuer</span></a>
      <a href="Redacteur2.php" id="mid">
         <span>Visualiser</span></a>
      <a href="Redacteur4.php" id="right">
         <span>Confirmer</span></a>
      </div>
      <div class="center">
        
        <div class="top-center">
          <form method="POST">
          <div class="input">
         <?php
          
           
          
          $results = $cnx->query("SELECT * FROM pokapresse.article where nummag is null;");
           while ($ligne = $results->fetch(PDO::FETCH_OBJ)) {
            echo "<div class='petit'>";
            echo  "<span>$ligne->titre</span>";
           
               echo "<input type= checkbox  name='$ligne->titre' value='$ligne->titre' />";
               echo "</div>";
           }


           ?>
           </div>
           <select name="Maquettiste" >
            <option value="" selected="selected">Selectionner maquettiste</option>
            <?php
			include("connexion.inc.php");
            $results = $cnx->query("SELECT * FROM pokapresse.participant where metier='Maquettiste' ;");
            while ($ligne = $results->fetch(PDO::FETCH_OBJ)) {
                echo "<option value=$ligne->matricule>$ligne->nom</option>";
            }
            ?>
           </select>
        <div class="bottom-center">
          <input type="reset" id="reset" value="Annuler" />
          <input type="submit" id="submit" value="Confirmer" name="submit" />
        </div>
      </form>
      </div>



    


  </body>
</html>
<?php }else{
  
  header("location: Connexion.php");} } else{
  
  header("location: Connexion.php");}?>