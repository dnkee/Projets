<?php 
session_start();

if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
  if($_SESSION['metier']=="Redacteur"){
  $id=$_SESSION['id'];
      if(isset($_POST["Mag"])){

        
   
      ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Redacteur3.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
    <title>Document</title>
  </head>
  <body>

  <?php
  include "header.inc.html";
  ?>
    <div class="navchoice">

      <a href="Redacteur1.php" id="left">
         <span>Attribuer</span></a>
      <a href="Redacteur2.php" id="mid">
         <span>Visualiser</span></a>
      <a href="Redacteur4.php" id="right">
         <span>Confirmer</span></a>
      </div>
  
    <div class="conteneur">
      <div class="left">





     <?php
     $id=$_POST["Mag"];
     echo $id;
     include "connexion.inc.php";
     $result=$cnx->query("SELECT numero_magazine.version as vm,lien_maquette,mois,annees
     FROM pokapresse.numero_magazine, pokapresse.maquette , pokapresse.choisir, pokapresse.image
     WHERE maquette.version=numero_magazine.version and nummag=$id ;" );
     $ligne = $result->fetch(PDO::FETCH_OBJ); 
     $req2="SELECT numero_magazine.version as vm,lien_maquette,mois,annees , fichier_image
     FROM pokapresse.numero_magazine, pokapresse.maquette , pokapresse.choisir, pokapresse.image
     WHERE maquette.version=numero_magazine.version and nummag=$id and choisir.n_image = image.n_image and  maquette.version = choisir.version;" ;
     $result2=$cnx->query($req2);
     $ligne2 = $result2->fetch(PDO::FETCH_OBJ);

     ?>



     
        <img src="<?php  echo $ligne2->fichier_image?>" alt="" />
        <span> Version : <?php  echo $ligne->vm?></span>
        <span> Date : <?php echo $ligne->mois." - ".$ligne->annees?> </span>
      </div>
      
      




      
      <div class="right">
        <div class="right_top">
          <h2>Articles selectionnés</h2>
          <div class="conteneur-bar">
          <ul>  
    <?php  
       $result2=$cnx->query("SELECT titre, date_mise_en_ligne, contenu from pokapresse.article where nummag=$id ;");
      while($ligne = $result2->fetch(PDO::FETCH_OBJ)){   
            ?>
          <li>

            <div class="b">
              <span>Titre :</span>                
              <?php echo $ligne->titre ?>
            </div>
            <div class="c">
              <span>Date :</span>
              <?php echo $ligne->date_mise_en_ligne ?>
            </div>
            <a href=<?php echo $ligne->contenu ?> ><i class="fa-regular fa-circle-down"></i></a>
          </li>
   
            <?php } 
    ?>
    </ul>
          </div>
        </div>
        <div class="right_bottom">
          <h2>Ventes</h2>
          <?php 
          $result__=$cnx->query("SELECT sum(quantite_vendu) as qte from vendre where nummag = $id;");
     $ligne = $result__->fetch(PDO::FETCH_OBJ);?>
          <div class="content"><span>Quantité vendus : <?php echo $ligne->qte ?></span></div>
        </div>
      </div>
     
    </div>
  </body>
</html>

<?php    };?>
<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>