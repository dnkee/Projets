<?php 
session_start();
if(isset($_SESSION['login']) &&isset($_SESSION['id']) && isset($_SESSION['mdp']) && isset($_SESSION['metier'])){
    if($_SESSION['metier']=="Redacteur"){
  $id=$_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="Redacteur4.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
    <title>Document</title>
  </head>
  <body>
  <?php
  include "header.inc.html";
  include "connexion.inc.php";
  ?>
   <div class="navchoice">
      <a href="Redacteur1.php" id="left">
         <span>Attribuer</span></a>
      <a href="Redacteur2.php" id="mid">
         <span>Visualiser</span></a>
      <a href="Redacteur4.php" id="right">
         <span>Confirmer</span></a>
      </div>


    <div class="conteneur">
    <form method="POST" class=jesuiscache>
        <ul>
            <?php  
                include "connexion.inc.php";
                $result = $cnx->query("SELECT maquette.version as vers ,
                                        date_version as annees,
                                        fichier_image,
                                        nummag
                                        FROM pokapresse.maquette,
                                        pokapresse.numero_magazine,
                                        pokapresse.choisir,
                                        pokapresse.image
                                        WHERE reference=numero_magazine.version 
                                        and image.n_image = choisir.n_image 
                                        and  maquette.version = choisir.version;")  ; 
                $count = 0;
                $num = 0;
                while ($ligne = $result->fetch(PDO::FETCH_OBJ)) {  
                    if ($ligne->nummag != $num) {
                        $count = 0;
                        echo '</ul><input name="submit" type="submit" id="submit" value="Confirmer" /></form>';
                    }
                    if ($count == 0) {
                        $num = $ligne->nummag;
                        echo '<h2>Num Mag : '.$ligne->nummag.'</h2><div class="barre"></div><form method="POST"><ul>';
                        $count += 1;
                    }
            ?>
            <li>
                <img src="<?php echo $ligne->fichier_image; ?>" alt="" />
                <div class="info_bottom">
                    <div class="infos_left">
                        <span>Version: <?php echo $ligne->vers; ?></span>
                        <div class="barre"></div>
                        <span><?php echo $ligne->annees; ?></span>
                    </div>
                    <div class="infos_right">
                        <a href=""><i class="fa-regular fa-circle-down"></i></a>
                    </div>
                </div>
                <input type="radio" name="maquette" id="maq" value="<?php echo $ligne->nummag." ".$ligne->vers; ?>"/>
                <label for="maq" id="ma"></label>
            </li>
            <?php } ?>
        </ul>
        <input name="submit" type="submit" id="submit" value="Confirmer" />
    </form>
</div>


   <?php
			if (isset($_POST["submit"])){		
        $cnx->beginTransaction();
        $mois=date("m");
        $an=date("Y");
        $vers=$_POST['maquette'];
        echo $vers;
        $mots=explode(" ",$vers);
        print_r($mots);
        $num_mag=$mots[0];
    
        
        $version=$mots[1];
  
        $req="UPDATE pokapresse.numero_magazine set version =  $version  where nummag=$num_mag;";
        echo $req;
				$result = $cnx->exec($req);
        $cnx->commit();
      }
?>
  </body>
</html>
<?php }else{
  
  header("location: Connexion.php");}} else{
  
  header("location: Connexion.php");}?>