<?php 
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation</title>
</head>
<body>

<div class="class"> 
    <h1>Etes-vous sûr de confirmer ?</h1>
    <form method="post" >
        <input type="submit" value="Annuler" name="submit">
        <input type="submit" value="Confirmer" name="submit">
    </form>
</div>

<?php
$cnx=$_POST["pdo"];

if(isset($_POST['submit'])){
    if ($_POST['submit'] == "Annuler"){
        echo "Action annulée.";
        $cnx->rollback();
        }
    else{
        echo "Action confirmée.";
        $cnx->commit();
    }
}
?>
</body>
</html>
