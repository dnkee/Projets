from fltk import *
from random import *
from time import *
from math import *
largeur_fenetre = 1420
hauteur_fenetre = 820
cote_map = 700
xa_map = (largeur_fenetre - cote_map)/2
ya_map = (hauteur_fenetre - cote_map)/2


def adapter_taille_texte(taille_pixels, texte, police: str = "Helvetica"):
    taille_min, taille_max = 1, 1000

    while taille_min < taille_max:
        taille_test = (taille_min + taille_max) // 2
        largeur, hauteur = taille_texte(texte, police, taille_test)

        precision = 1

        if abs(hauteur - taille_pixels[1]) < precision:
            return taille_test
        elif hauteur < taille_pixels[1]:
            taille_min = taille_test + 1
        else:
            taille_max = taille_test - 1

    return taille_min
def initialisation_bord():
	mise_a_jour()
	liste_bord = []
	for i in range(cote_map+1):
		liste_bord.append((xa_map+i, ya_map))
	for i in range(1, cote_map):
		liste_bord.append((xa_map+cote_map, ya_map+i))

	for i in range(cote_map+1):
		liste_bord.append((xa_map+cote_map-i,ya_map+cote_map))

	for i in range(1,cote_map):	
		liste_bord.append((xa_map,ya_map+cote_map-i))
	return liste_bord
def calculer_aire_polygone(sommets):#Utilisation du théorème de green
	"""
	>>> calculer_aire_polygone([(1,1),(4,1),(4,4),(3,4),(3,3),(2,3),(2,4),(1,4)])
	8.0
	>>> calculer_aire_polygone([(1,1),(2,1),(2,2),(1,2)])
	1.0
	
	"""
	n = len(sommets)
	aire = 0
	for i in range(n):
		x1, y1 = sommets[i]
		x2, y2 = sommets[(i + 1) % n]
		aire += (x1 * y2) - (x2 * y1)
	aire = abs(aire) / 2
	return aire
def est_point_dans_polygone(point, polygone):
	"""
	>>> est_point_dans_polygone((3,2),[(1,1),(4,1),(4,4),(3,4),(3,3),(2,3),(2,4),(1,4)])
	True
	>>> est_point_dans_polygone((5,5),[(1,1),(4,1),(4,4),(3,4),(3,3),(2,3),(2,4),(1,4)])
	False
	"""
	x, y = point
	n = len(polygone)
	est_a_l_interieur = False
	j = n - 1

	for i in range(n):
		xi, yi = polygone[i]
		xj, yj = polygone[j]

		if yi < y and yj >= y or yj < y and yi >= y:
			if xi + (y - yi) / (yj - yi) * (xj - xi) < x:
				est_a_l_interieur = not est_a_l_interieur

		j = i

	return est_a_l_interieur
def contour(arrivee,depart,liste_bord):
	"""
	>>> liste_bord=[(1,1),(2,1),(3,1),(4,1),(4,2),(4,3),(4,4),(3,4),(3,3),(2,3),(2,4),(1,4),(1,3),(1,2)]
	>>> contour((2,1),(1,3),liste_bord)
	[[(2, 3), (3, 3), (4, 3), (4, 2), (4, 1), (3, 1)], [(1, 4), (2, 4), (3, 4), (4, 4), (4, 3), (4, 2), (4, 1), (3, 1)]]

	"""
	liste=[]
	liste2=[]
	xd=depart[0]
	yd=depart[1]
	point=depart
	direction='gauche'
	while point!=arrivee:
		if direction=='droite':	
			if (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste.append((xd,yd))
			elif (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste.append((xd,yd))		
				direction='bas'
			elif (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='haut'
		if direction=='gauche':
			if (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste.append((xd,yd))			
			elif (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='bas'			
			elif (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='haut'
		if direction=='haut':
			if (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste.append((xd,yd))			
			elif (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='droite'				
			elif (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='gauche'			
		if direction=='bas':
			if (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste.append((xd,yd))			
			elif (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='droite'				
			elif (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste.append((xd,yd))
				direction='gauche'
	point=depart
	xd=depart[0]
	yd=depart[1]
	direction='droite'
	while point!=arrivee:
		if direction=='droite':	
			if (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste2.append((xd,yd))
			elif (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='haut'
			elif (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste2.append((xd,yd))		
				direction='bas'

		if direction=='gauche':
			if (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste2.append((xd,yd))			
			elif (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='haut'			
			elif (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='bas'			

		if direction=='haut':
			if (xd,yd-1) in liste_bord:
				yd-=1
				point=(xd,yd)
				liste2.append((xd,yd))			
			elif (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='droite'				
			elif (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='gauche'			
		if direction=='bas':
			if (xd,yd+1) in liste_bord:
				yd+=1
				point=(xd,yd)
				liste2.append((xd,yd))			
			elif (xd+1,yd) in liste_bord:
				xd+=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='droite'				
			elif (xd-1,yd) in liste_bord:
				xd-=1
				point=(xd,yd)
				liste2.append((xd,yd))
				direction='gauche'	
	liste.pop()
	liste2.pop()	
	if len(liste)<len(liste2):
		return [liste,liste2]
	else:
		return [liste2,liste]
def separer_liste(liste,liste_cible,liste_remplacante):

	a=None
	i=0
	while i<len(liste):
		if liste[i] in liste_cible:
			if a== None:
				a=i	
			liste.pop(i)
		else:
			i+=1
	xa,ya=liste_remplacante[0]
	xb,yb=liste[a]
	
	if liste_remplacante[0]==liste[int((a-1)%len(liste))] and liste_remplacante[len(liste_remplacante)-1]==liste[a]:
		for i in range(len(liste_remplacante)-2,0,-1):
			liste.insert(a,liste_remplacante[i])
	elif liste_remplacante[0]==liste[a] and liste_remplacante[len(liste_remplacante)-1]==liste[int((a-1)%len(liste))] :
		for i in range(1,len(liste_remplacante)-1):
			liste.insert(a,liste_remplacante[i])
	return liste
def sommet_polygone(lst_dessin):
	"""
	>>> sommet_polygone([(0,0),(1,0),(2,0),(2,1),(2,2),(1,2),(0,2),(0,1)])
	[(0, 0), (2, 0), (2, 2), (0, 2)]
	
	>>> sommet_polygone([(1,1),(2,1),(3,1),(4,1),(4,2),(4,3),(4,4),(3,4),(3,3),(2,3),(2,4),(1,4),(1,3),(1,2)])
	[(1, 1), (4, 1), (4, 4), (3, 4), (3, 3), (2, 3), (2, 4), (1, 4)]
	
	"""
	liste_sommet=[]
	n=len(lst_dessin)
	for i in range(n):
		xa=lst_dessin[(i-1)%n][0]
		ya=lst_dessin[(i-1)%n][1]
		xb=lst_dessin[(i+1)%n][0]
		yb=lst_dessin[(i+1)%n][1]
		if xa!=xb and ya!=yb:
			liste_sommet.append(lst_dessin[i])
	return liste_sommet	
#=====================COLLISION=====================
def collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord):
	for element in liste_qix:
		xq,yq,direction=element
		if (xj,yj) not in liste_bord:
			if sqrt((xj-xq)**2+(yj-yq)**2)<=50:
				return True
			for element in lst_trainee:
				x,y=element
				if sqrt((x-xq)**2+(y-yq)**2)<=50:
					return True
	return False
def collision_sparx(xj,yj,liste_sparx):
	for element in liste_sparx:
		xs,ys=element
		if (xj,yj)==(xs,ys):
			return True
	return False
		
def perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord):
	vie_joueur-=1
	mode='BASE'
	if (xj,yj) not in liste_bord:
		lst_trainee[:]=[]
		xj,yj=lst_dessin[0]
		lst_dessin[:]=[]
		efface_tout()
	
	return (mode,vie_joueur,xj,yj,True,time())
	
def reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord):
	mode='BASE'
	if (xj,yj) not in liste_bord:
		lst_trainee[:]=[]
		xj,yj=lst_dessin[0]
		lst_dessin[:]=[]
		efface_tout()
		
		
	return (mode,vie_joueur,xj,yj,True,time())
#=====================DEPLACEMENT==================
	#----------QIX-------------
def deplacement_qix(xq, yq, direction,liste_bord):
	if direction == 1 and est_point_dans_polygone((xq + 50, yq),sommet_polygone(liste_bord))==True:
		xq += 1
	elif direction == -1 and est_point_dans_polygone((xq - 50, yq),sommet_polygone(liste_bord))==True:
		xq -= 1
	elif direction == 2 and est_point_dans_polygone((xq, yq - 50),sommet_polygone(liste_bord))==True:
		yq -= 1
	elif direction == -2 and est_point_dans_polygone((xq, yq + 50),sommet_polygone(liste_bord))==True:
		yq += 1
	elif direction == 3 and est_point_dans_polygone((xq - 50, yq + 50), sommet_polygone(liste_bord))==True:
		xq -= 1
		yq += 1
	elif direction == -3 and est_point_dans_polygone((xq + 50, yq - 50), sommet_polygone(liste_bord))==True:
		xq += 1
		yq -= 1
	elif direction == 4 and est_point_dans_polygone((xq+50, yq + 50), sommet_polygone(liste_bord))==True:
		yq += 1
		xq += 1
	elif direction == -4 and est_point_dans_polygone((xq-50, yq - 50), sommet_polygone(liste_bord))==True:
		yq -= 1
		xq -= 1
	return (xq, yq, direction)
def affiche_qix(liste_qix,color1,color2):
	for element in liste_qix:
		xq, yq, position_precedente = element
		cercle(xq, yq, 50,color1,color2)
def deplacement_qixs(liste_qix, tempsqix,vitesse_qix):
	for i in range(vitesse_qix):
		for j in range(len(liste_qix)):
			xq,yq,direction=liste_qix[j]
			liste_qix[j]=list(deplacement_qix(xq,yq,direction,liste_bord))
	return liste_qix, tempsqix
def changement_direction_qix(liste_qix):
	for i in range(len(liste_qix)):
		nouvelle_direction=randint(-4,4)
		while -1*nouvelle_direction==liste_qix[i][2] or nouvelle_direction==0:
			nouvelle_direction=randint(-4,4)
		liste_qix[i][2]=nouvelle_direction		
def deplacement_sparx(xs,ys,liste_bord,sens,liste_qix):
	longueur_liste=len(liste_bord)
	if sens=="horaire":
		a=1
	else:
		a=-1
	for i in range(len(liste_bord)):
		if liste_bord[i]==(xs,ys):
			return liste_bord[(i+a)%longueur_liste]	
	for i in range(len(liste_qix)):
		xq,yq,direction=liste_qix[i]
		if est_point_dans_polygone((xq,yq),sommet_polygone(liste_bord)):
			break
	if xq>xs:
		xs+=1
	if xq<xs:
		xs-=1
	if yq>ys:
		ys+=1
	if yq<ys:
		ys-=1
	return(xs,ys)
def deplacement_sparxs(liste_sparx,liste_qix,vitesse_sparx,liste_bord):
	for j in range(vitesse_sparx):
		for i in range(len(liste_sparx)):
			xs,ys=liste_sparx[i]
			if i%2==0:
				sens="horaire"
			else:
				sens ="antihoraire"
			xs,ys =deplacement_sparx(xs,ys,liste_bord,sens,liste_qix)
			liste_sparx[i]=(xs,ys)
def affiche_sparx(liste_sparx):
	for element in liste_sparx:
		xs, ys = element
		cercle(xs, ys, 3, "blue", "blue")	
	

			
def changement_vitesse(vitesse_joueur,delaisvitesse,joueur):
	if joueur==1:
		touche="Shift_R"
	else:
		touche="a"
	if touche_pressee(touche)==True:
		if time()-delaisvitesse>0.5:
			delaisvitesse=time()
			if vitesse_joueur=="LENT":
				vitesse_joueur="RAPIDE"	
			else:
				vitesse_joueur="LENT"
	return (vitesse_joueur,delaisvitesse)	


def affiche_info_joueur(joueur, Score, vie_joueur, mode, vitesse_joueur):
	if joueur == 1:
		xjoueur1 = 50
		yjoueur1 = 1 * hauteur_fenetre / 4
		rectangle(xjoueur1, yjoueur1, xjoueur1 + 200, yjoueur1 + 500, "white", 'red')
		texte(xjoueur1 + 100, yjoueur1 + 30, "JOUEUR 1", couleur="white",taille=adapter_taille_texte((40, 20), "JOUEUR X"),ancrage="center")
		if vie_joueur > 0:
			affiche_vie(vie_joueur, xjoueur1+80, yjoueur1+ 60,"red")
			affiche_mode(mode, xjoueur1+100, yjoueur1+ 90)
			affiche_vitesse(vitesse_joueur, xjoueur1+100, yjoueur1+ 150)
			affiche_score(Score, xjoueur1+100, yjoueur1+ 210)
		else:
			texte(xjoueur1 + 100, yjoueur1 + 60, "MORT", couleur="white", taille=adapter_taille_texte((40, 20), "JOUEUR X"), ancrage="center")

	elif joueur == 2:
		xjoueur2 = xa_map + cote_map + 50
		yjoueur2 = 1 * hauteur_fenetre / 4
		rectangle(xjoueur2, yjoueur2, xjoueur2 + 200, yjoueur2 + 500, "white", 'purple')
		texte(xjoueur2 + 100, yjoueur2 + 30, "JOUEUR 2", couleur="white",
			  taille=adapter_taille_texte((40, 20), "JOUEUR X"), ancrage="center")
		if vie_joueur > 0:
			affiche_vie(vie_joueur, xjoueur2 + 80, yjoueur2 + 60,"purple")
			affiche_mode(mode, xjoueur2 + 100, yjoueur2 + 90)
			affiche_vitesse(vitesse_joueur, xjoueur2 + 100, yjoueur2 + 150)
			affiche_score(Score, xjoueur2 + 100, yjoueur2 + 210)
		else:
			texte(xjoueur2 + 100, yjoueur2 + 60, "MORT", couleur="white", taille=adapter_taille_texte((40, 20), "JOUEUR X"), ancrage="center")


def changement_mode(mode,delaismode,joueur):
	if joueur==1:
		touche="Return"
	else:
		touche="f"
	if touche_pressee(touche)==True:
		if time()-delaismode>0.5:
			delaismode=time()
			if mode=='DESSIN':
				return ('BASE',delaismode)
			else:
				return ('DESSIN',delaismode)
	return (mode,delaismode)
def affiche_mode(mode,x,y):
	texte(x,y,"MODE:\n"+mode,couleur='White',taille=adapter_taille_texte((40,20),"MODE:\nX JOUEUR"),ancrage="center")
def affiche_vitesse(vitesse_joueur,x,y):
	texte(x,y,"VITESSE:\n"+vitesse_joueur,couleur='White',taille=adapter_taille_texte((40,20),"MODE:\nX JOUEUR"),ancrage="center")
def deplacement_joueur_base(xj,yj,joueur,liste_bord):
	if joueur==1:
		a='Right'
		b='Left'
		c='Up'
		d='Down'
	else:
		a='d'
		b='q'
		c='z'
		d='s'
	if touche_pressee(a)==True :
		if(xj+1,yj) in liste_bord:
			xj+=1
	elif touche_pressee(b)==True:
		if (xj-1,yj) in liste_bord:
			xj-=1
	elif touche_pressee(c)==True:
		if(xj,yj-1) in liste_bord:
			yj-=1
	elif touche_pressee(d)==True:
		if(xj,yj+1) in liste_bord:
			yj+=1
	return(xj,yj)

def Interface():
	for i in range(200):
		sleep(0.02)
		efface_tout()
		rectangle(0, 0, largeur_fenetre, hauteur_fenetre, 'black', 'black')
		texte(largeur_fenetre/2,hauteur_fenetre/2,'QIX',couleur='red',taille=i, ancrage="center")
		mise_a_jour()
		if donne_ev():
			break
	sleep(0.5)

	rectangle(0, 0, largeur_fenetre, hauteur_fenetre, 'black', 'black')
	texte(710,100,"QIX","red",taille=adapter_taille_texte((250,150),"QIX"),ancrage="center")
	rectangle(575,200,845,300,'white','red')
	texte(710,230,"1 JOUEUR","black",taille=adapter_taille_texte((250,50),"1 JOUEUR"),ancrage="center")
	rectangle(575,350,845,450,'white','red')
	texte(710,380,"2 JOUEUR","black",taille=adapter_taille_texte((250,50),"2 JOUEUR"),ancrage="center")
	rectangle(575,500,845,600,'white','red')
	texte(710,530,"SAUVEGARDE","black",taille=adapter_taille_texte((250,40),"SAUVEGARDE"),ancrage="center")
	rectangle(575, 650, 845, 750, 'white', 'red')
	texte(710, 680, "QUITTER", "black", taille=adapter_taille_texte((250,50),"QUITTER"), ancrage="center")
	mise_a_jour()
	while True:
		x,y=attend_clic_gauche()
		if 575<x<845 and 200<y<300:
			return "1 JOUEUR"
		if 575<x<845 and 350<y<450:
			return "2 JOUEUR"
		if 575<x<845 and 500<y<600:
			return "Sauvegarde"
		if 575 < x < 845 and 650 < y < 750:
			exit()


		
def calcul_pourcentage_total(liste_bord,Air_total):
	return ((Air_total-calculer_aire_polygone(sommet_polygone(liste_bord)))/Air_total)*100
	
def score(liste_dessins,Air_total):
	scoretotal=0
	for element in liste_dessins:
		if element[2]=="LENT":
			scoretotal+=(calculer_aire_polygone(element[0])/Air_total)*50000
		else:
			scoretotal+=(calculer_aire_polygone(element[0])/Air_total)*25000
	return scoretotal
def affiche_score(Score,xsc,ysc):
	texte(xsc,ysc,"SCORE:"+str(int(Score)),couleur='White',taille=adapter_taille_texte((80,30),"MODE:\nX JOUEUR"),ancrage="center")
def affiche_pourcentage(pourcentage):
	texte(710,20,"POURCENTAGE: "+str(int(pourcentage))+"%",couleur='White',taille=adapter_taille_texte((40,20),"MODE:\nX JOUEUR"),ancrage="center")
		


def deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,position_precedente,joueur,liste_bord):
	if joueur==1:
		a='Right'
		b='Left'
		c='Up'
		d='Down'
		couleur="red"
	else:
		a='d'
		b='q'
		c='z'
		d='s'
		couleur="purple"
	position_actuelle=(xj,yj)
	if touche_pressee(a)==True:
		direction_joueur=(xj+1,yj)
		direction_inverse=(xj-1,yj)
	elif touche_pressee(b)==True:
		direction_joueur=(xj-1,yj)
		direction_inverse=(xj+1,yj)
	elif touche_pressee(c)==True:
		direction_joueur=(xj,yj-1)
		direction_inverse=(xj,yj+1)
	elif touche_pressee(d)==True:
		direction_joueur=(xj,yj+1)
		direction_inverse=(xj,yj-1)
	else:
		return (xj,yj,position_precedente,mode)
	for element in liste_obstacle:
		if len(element)==2:
			point1=element[0]
			point2=element[1]
			liste_sommet_obstacle=[point1,(point2[0],point1[1]),point2,(point1[0],point2[1])]
		else:
			liste_sommet_obstacle=element
		if est_point_dans_polygone(direction_joueur,liste_sommet_obstacle)==True:
			return (xj,yj,position_precedente,mode)
	
	if (xj,yj) in liste_bord:
		lst_dessin[:]=[]
		lst_dessin2[:]=[]
		lst_trainee[:]=[]
		
		if direction_joueur not in liste_bord:
			if est_point_dans_polygone(direction_joueur,sommet_polygone(liste_bord))==True:
				lst_dessin.append((xj,yj))
				lst_dessin.append(direction_joueur)

				lst_trainee.insert(0,(xj,yj))
				lst_trainee.append((xj,yj))
				lst_trainee.insert(0,direction_joueur)
				lst_trainee.append(direction_joueur)
				xj,yj=direction_joueur
				return(xj,yj,position_actuelle,mode)
		elif direction_joueur in liste_bord:
			xj,yj=direction_joueur
			return(xj,yj,None,mode)
	else:		
		if direction_joueur==position_precedente:
			return(xj,yj,position_precedente,mode)
		else:
			if direction_joueur not in liste_bord:
				xj,yj=direction_joueur
				lst_dessin.append((xj,yj))
				lst_trainee.insert(0,(xj,yj))
				lst_trainee.append((xj,yj))
			elif direction_joueur in liste_bord:
				xj,yj=direction_joueur
				lst_dessin.append((xj,yj))
				lst_trainee.insert(0,(xj,yj))
				lst_trainee.append((xj,yj))
				a=(dessin(lst_dessin,liste_bord,liste_qix),couleur,vitesse_joueur)
				liste_dessins.append(a)	
				mode="BASE"	
	return (xj,yj,position_actuelle,mode)
def collision_trainee(lst_trainee,xj,yj):
	for i in range(1,len(lst_trainee)-1):
		if lst_trainee[i]==(xj,yj):
			return True
		
	return False
def creation_bonus(nombrepomme):
	lst = []
	for i in range(nombrepomme):
		x = randint(int(xa_map + 5), int(xa_map + cote_map - 5))
		x = x - (x % 5)
		y = randint(int(ya_map + 5), int(ya_map + cote_map - 5))
		y = y - (y % 5)
		pommes = (x, y)
		lst.append(pommes)
	return (lst)


def affiche_pomme(pommes):
	for i in pommes:
		cercle(i[0], i[1], 5, 'green', 'green')


def affiche_bonus(bm):
	if bm!=[]:
		cercle(bm[0][0],bm[0][1],6,'pink','yellow')

def mange_bonus(xj, yj, pommes,temps_deplacement_qix,temps_sparx,Score,vie_joueur,delais_deplacement,color1,color2):
	for element in pommes:
		if (xj, yj) == element:
			pommes.remove(element)
			with open("bonus","r") as bonus, open ("malus",'r') as malus:
				b=bonus.readlines()
				m=malus.readlines()
				choix=randint(1,2)
				chiffre=randint(1,3)
				if choix ==1:
					if chiffre ==1:
						temps_deplacement_qix+=float(b[1][-2:-1])
					if chiffre==2:
						temps_sparx+=float(b[3][-2:-1])

					if chiffre==3:
						vie_joueur+=int(b[5][-2:-1])
				if choix ==2:
					if chiffre==1:
						delais_deplacement+=float(m[1][-2:-1])
					if chiffre==2:
						vie_joueur-=int(m[5][-2:-1])
					if chiffre==3:
						color1,color2="",""

	return pommes,temps_deplacement_qix,temps_sparx,Score,vie_joueur,delais_deplacement,color1,color2

def mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite):
	for element in pommes:
		if (xj,yj)==element:
			pommes.remove(element)
			return pommes,True,time()
	return pommes,Invincibilite,temps_invincibilite
	
def affiche_joueur(xj,yj,couleur):
	cercle(xj,yj,5,'white',couleur)		
def dessin(lst_dessin,liste_bord,liste_qix):
	
	nb_qix=len(liste_qix)
	bord_ext=contour(lst_dessin[0],lst_dessin[len(lst_dessin)-1],liste_bord)
	sommet=sommet_polygone(lst_dessin+bord_ext[0])
	if nb_qix==1:
		xq,yq,direction=liste_qix[0]
		if est_point_dans_polygone((xq,yq),sommet):
			bord_ext=bord_ext[1]
			liste_bord=separer_liste(liste_bord,bord_ext,lst_dessin)
			lst_dessin=lst_dessin+bord_ext
			lst_dessin2=sommet_polygone(lst_dessin)
		else:
			bord_ext=bord_ext[0]
			liste_bord=separer_liste(liste_bord,bord_ext,lst_dessin)
			lst_dessin=lst_dessin+bord_ext
			lst_dessin2=sommet_polygone(lst_dessin)
	else:
		nb_qix_polygone=0
		for qix in liste_qix:
			xq,yq,direction=qix
			if est_point_dans_polygone((xq,yq),sommet):
				nb_qix_polygone+=1
		if nb_qix_polygone<nb_qix-nb_qix_polygone:
			bord_ext=bord_ext[0]
			liste_bord=separer_liste(liste_bord,bord_ext,lst_dessin)
			lst_dessin=lst_dessin+bord_ext
			lst_dessin2=sommet_polygone(lst_dessin)
		elif nb_qix_polygone>nb_qix-nb_qix_polygone :
			bord_ext=bord_ext[1]
			liste_bord=separer_liste(liste_bord,bord_ext,lst_dessin)
			lst_dessin=lst_dessin+bord_ext
			lst_dessin2=sommet_polygone(lst_dessin)
		else:
			if calculer_aire_polygone(sommet_polygone(lst_dessin+bord_ext[1]))>calculer_aire_polygone(sommet_polygone(lst_dessin+bord_ext[0])):
				liste_bord=separer_liste(liste_bord,bord_ext[0],lst_dessin)
				lst_dessin=lst_dessin+bord_ext[0]
			else:
				liste_bord=separer_liste(liste_bord,bord_ext[1],lst_dessin)
				lst_dessin=lst_dessin+bord_ext[1]
			lst_dessin2=sommet_polygone(lst_dessin)
	return lst_dessin2
	
	
def affiche_dessins(liste_dessins):
	for element in liste_dessins:
		polygone(element[0],'white',element[1])
		
def affiche_trainee(lst_trainee):
	polygone(lst_trainee,'white','white')
					


def coordonnee_obstacles(n):
	liste_obstacle=[]
	obst=open("obstacles")
	obstacle=obst.readlines()
	obst.close()
	b=randint(0,12)
	a=randint(0,1)
	while b==a:
		b=randint(0,3)
	liste_obstacle.append(eval(obstacle[b][:-1]))
	liste_obstacle.append(eval(obstacle[a][:-1]))
	return liste_obstacle
def affiche_obstacle(liste_obstacle):
	for element in liste_obstacle:
		polygone(element,"white", "grey")


def collision_obstacle(xj,yj,liste_obstacle):
	if xj>=liste_obstacle[0][0][0] and xj<=liste_obstacle[0][1][0] and yj>=liste_obstacle[0][0][1] and yj<=liste_obstacle[0][1][1]:
		return True
def affiche_jeu():
	rectangle(0,0,largeur_fenetre,hauteur_fenetre,'black','black')
	rectangle(xa_map,ya_map,xa_map+cote_map,ya_map+cote_map,'white',epaisseur=3)
	texte(40,20,'QIX',couleur='red',taille=adapter_taille_texte((100,150),"MODE:\nX JOUEUR"))
def Niveau_gagner(Niveau):
	efface_tout()
	affiche_jeu()
	for i in range(adapter_taille_texte((20,100),'NIVEAU GAGNÉ')):
		efface_tout()
		affiche_jeu()
		texte(710,410,'NIVEAU '+str(Niveau)+" GAGNÉ",couleur='red',taille=i, ancrage="center")
		mise_a_jour()
	sleep(1)
	if Niveau+1==6:
		for i in range(adapter_taille_texte((20, 100), 'NIVEAU GAGNÉ')):
			efface_tout()
			affiche_jeu()
			texte(710, 410, 'VOUS AVEZ GAGNÉ ' + str(Niveau) + " GAGNÉ", couleur='red', taille=i, ancrage="center")
			mise_a_jour()
		sleep(1)
	else:
		for i in range(adapter_taille_texte((100,100),"NIVEAU")):
			efface_tout()
			affiche_jeu()
			texte(710,410,'NIVEAU '+str(Niveau+1),couleur='red',taille=i, ancrage="center")
			mise_a_jour()
		sleep(1)
	return Niveau+1
	
def affiche_vie(vie_joueur,xv,yv,couleur):
	for i in range(vie_joueur):
		cercle(xv,yv,5,"white",couleur)
		xv+=20
def perdu():
	efface_tout()
	affiche_jeu()
	texte(710,410,'VOUS AVEZ PERDU',couleur='red',taille=100, ancrage="center")
	mise_a_jour()
def affiche_sauvegarde(entree,largeur_fenetre,hauteur_fenetre):
	rectangle(0,0,largeur_fenetre,hauteur_fenetre,"black","black")
	rectangle(5, 5, 55, 55,"white","red")
	ligne(5,5,55,55,"white")
	ligne(5, 55, 55, 5, "white")
	liste_sauvegarde=[]
	fichier=open(entree,'r')
	lst=fichier.readlines()	
	fichier.close()
	NUM_SAUVEGARDE=0
	for i in range(len(lst)):
		lst[i]=lst[i][:-1]
	for j in range(len(lst)):
		if lst[j][:-2]=="SAUVEGARDE":
			NUM_SAUVEGARDE+=1
			if lst[j+1]=="VIDE":
				rectangle((NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10,hauteur_fenetre/2-200,NUM_SAUVEGARDE*(largeur_fenetre/5)-10,hauteur_fenetre/2+200,'white',"black")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-150,lst[j],"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-100,lst[j+1],"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				liste_sauvegarde.append(lst[j:j+2])

			elif lst[j+1]=="1 JOUEUR":
				mode="Mode 1 Joueur"#mode
				Niveau="Niveau "+str(lst[j+2])#Niveau
				Pourcentage="Pourcentage : "+str(int(float(lst[j+3])))+"%"#Pourcentage
				vie_joueur="Vie Joueur : "+str(lst[j+4])#vie_joueur
				rectangle((NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10,hauteur_fenetre/2-200,NUM_SAUVEGARDE*(largeur_fenetre/5)-10,hauteur_fenetre/2+200,'white',"black")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-150,lst[j],"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-100,mode,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-50,Niveau,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2,Pourcentage,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2+50,vie_joueur,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				liste_sauvegarde.append(lst[j:j + 49])
			else:
				mode="Mode 2 Joueur"#mode
				Niveau = "Niveau " + str(lst[j + 2])  # Niveau
				Pourcentage = "Pourcentage : "+str(int(float(lst[j+3])))+"%"  # Pourcentage
				vie_joueur="Vie Joueur 1 : "+str(lst[j+4])#vie_joueur
				vie_joueur_2="Vie Joueur 2 : "+str(lst[j+5])#vie_joueur
				rectangle((NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10,hauteur_fenetre/2-200,NUM_SAUVEGARDE*(largeur_fenetre/5)-10,hauteur_fenetre/2+200,'white',"black")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-150,lst[j],"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-100,mode,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2-50,Niveau,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2,Pourcentage,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2+50,vie_joueur,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				texte((NUM_SAUVEGARDE*largeur_fenetre/5)-(NUM_SAUVEGARDE*(largeur_fenetre/5)-10-(NUM_SAUVEGARDE-1)*(largeur_fenetre/5)+10)/2,hauteur_fenetre/2+100,vie_joueur_2,"white",taille=adapter_taille_texte((20,20),"XXXXXXXX"),ancrage="center")
				liste_sauvegarde.append(lst[j:j+65])
	return liste_sauvegarde
def affiche_menu():
	efface_tout()
	rectangle(0, 0, largeur_fenetre, hauteur_fenetre, 'white', 'black')
	texte(710, 100, "MENU", "red", taille=adapter_taille_texte((250,150),"QIX"), ancrage="center")
	rectangle(575, 200, 845, 300, 'white', 'red')
	texte(710, 230, "REPRENDRE", "black", taille=adapter_taille_texte((250,40),"REPRENDRE"), ancrage="center")
	rectangle(575, 350, 845, 450, 'white', 'red')
	texte(710, 380, "SAUVEGARDER", "black", taille=adapter_taille_texte((250,40),"SAUVEGARDER"), ancrage="center")
	rectangle(575, 500, 845, 600, 'white', 'red')
	texte(710, 530, "QUITTER", "black", taille=adapter_taille_texte((250,50),"QUITTER"), ancrage="center")
	mise_a_jour()
def choix_menu(liste_parametre):
	while True:
		x, y=attend_clic_gauche()
		if 575 < x < 845 and 500 < y < 600:
			exit()
		if 575 < x < 845 and 200 < y < 300:
			break
		if 575 < x < 845 and 350 < y < 450:
			affiche_sauvegarde("Sauvegarde.txt", largeur_fenetre, hauteur_fenetre)
			return choix_sauvegarde(liste_parametre)

def choix_sauvegarde(liste_parametre):
	x2, y2 = attend_clic_gauche()
	while not (x2 < 55 and y2 < 55 and x2 > 5 and y2 > 5) and not (
			x2 > 0 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 1 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 1 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 2 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 2 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 3 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 3 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 4 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 4 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 5 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200):
		x2, y2 = attend_clic_gauche()
	if x2 < 55 and y2 < 55 and x2 > 5 and y2 > 5:
		efface_tout()
	if x2 > 0 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 1 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		sauvegarder("Sauvegarde.txt", "SAUVEGARDE 1",liste_parametre)

	if x2 > 1 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 2 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		sauvegarder("Sauvegarde.txt", "SAUVEGARDE 2", liste_parametre)

	if x2 > 2 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 3 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		sauvegarder("Sauvegarde.txt", "SAUVEGARDE 3", liste_parametre)


	if x2 > 3 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 4 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		sauvegarder("Sauvegarde.txt", "SAUVEGARDE 4", liste_parametre)


	if x2 > 4 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 5 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		sauvegarder("Sauvegarde.txt", "SAUVEGARDE 5", liste_parametre)
def Initialisation(Niveau,Mode_de_jeu):
	if Mode_de_jeu=="1 JOUEUR":
		#JOUEUR
		mode='BASE'
		vie_joueur=3
		xj=xa_map+cote_map/2
		yj=ya_map+cote_map
		lst_dessin=[]
		vitesse_joueur="RAPIDE"
		delais_deplacement=time()
		Invincibilite=False
		delais_bonus=time()
		temps_invincibilite=time()
		delaismode=time()
		delaisvitesse=time()
		color1 = "white"
		color2 = "blue"
		direction_interdite=None
		liste_joueur=[(xj,yj)]
		Score=0
		XSCORE=50
		YSCORE=50
		#DESSIN
		liste_dessins=[]
		lst_trainee=[]
		lst_dessin2=[]
	else:
		#JOUEUR 1
		mode='BASE'
		vie_joueur=3
		xj=xa_map
		yj=ya_map+cote_map
		lst_dessin=[]
		vitesse_joueur="RAPIDE"
		delais_deplacement=time()
		Invincibilite=False
		temps_invincibilite=time()
		delaismode=time()
		delaisvitesse=time()
		delais_bonus=time()
		color1 = "white"
		color2 = "blue"
		direction_interdite=None
		liste_joueur=[(xj,yj)]
		Score=0
		#DESSIN
		liste_dessins=[]
		lst_trainee=[]
		lst_dessin2=[]
		#JOUEUR 2
		mode_2='BASE'
		vie_joueur_2=3
		xj_2=xa_map+cote_map
		yj_2=ya_map+cote_map
		lst_dessin_2=[]
		vitesse_joueur_2="RAPIDE"
		delais_deplacement_2=time()
		Invincibilite_2=False
		temps_invincibilite_2=time()
		delaismode_2=time()
		delaisvitesse_2=time()
		direction_interdite_2=None
		liste_joueur_2=[(xj_2,yj_2)]
		Score_2=0
		#DESSIN
		liste_dessins_2=[]
		lst_trainee_2=[]
		lst_dessin2_2=[]

	#BONUS
	pommes=creation_bonus(3)
	bm = creation_bonus(1)
	#MAP
	liste_bord=initialisation_bord()
	#INFOS JEU
	pourcentage=0
	Air_total=calculer_aire_polygone([(xa_map,ya_map),(xa_map+cote_map,ya_map),(xa_map+cote_map,ya_map+cote_map),(xa_map,ya_map+cote_map)])#air vide de base
	Air_rempli=0
	latence_jeu=time()
	#OBSTACLE
	presence_obstacle=False
	liste_obstacle=[]
	tempsobstacle=time()
	if Niveau==1:
		#QIX
		taille_qix=50
		xq=xa_map+cote_map/2
		yq=ya_map+cote_map/2
		tempsqix=time()
		direction=randint(1,4)
		position_precedente=None
		liste_qix=[(xq,yq,None)]
		vitesse_qix=5
		temps_deplacement_qix=time()
		latence_qix=0.038
		#SPARX
		xs = xa_map + cote_map / 2
		ys = ya_map
		xs2 = xa_map + cote_map / 2
		ys2 = ya_map
		liste_sparx=[(xs,ys),(xs2,ys2)]
		vitesse_sparx=5
		temps_sparx=time()
		latence_sparx=0.02
	elif Niveau==2:
		#QIX
		taille_qix=50
		xq=xa_map+cote_map/2
		yq=ya_map+cote_map/2
		tempsqix=time()
		direction=randint(1,4)
		position_precedente=None
		liste_qix=[(xq,yq,None)]
		vitesse_qix=5
		temps_deplacement_qix=time()
		latence_qix=0.038
		#SPARX
		xs = xa_map + cote_map / 2
		ys = ya_map
		xs2= xa_map + cote_map / 2
		ys2= ya_map
		xs3= xa_map
		ys3= ya_map + cote_map / 2
		xs4= xa_map + cote_map
		ys4= ya_map + cote_map / 2
		liste_sparx=[(xs,ys),(xs2,ys2),(xs3,ys3),(xs4,ys4)]
		vitesse_sparx=5
		temps_sparx=time()
		latence_sparx=0.02
	elif Niveau==3:
		#QIX
		taille_qix=50
		xq=xa_map+cote_map/2
		yq=ya_map+cote_map/2
		tempsqix=time()
		direction=randint(1,4)
		position_precedente=None
		liste_qix=[(xq,yq,None)]
		vitesse_qix=5
		temps_deplacement_qix=time()
		latence_qix=0.019
		#SPARX
		xs = xa_map + cote_map / 2
		ys = ya_map
		xs2= xa_map + cote_map / 2
		ys2= ya_map
		xs3= xa_map
		ys3= ya_map + cote_map / 2
		xs4= xa_map + cote_map
		ys4= ya_map + cote_map / 2
		liste_sparx=[(xs,ys),(xs2,ys2),(xs3,ys3),(xs4,ys4)]
		vitesse_sparx=5
		temps_sparx=time()
		latence_sparx=0.019
	elif Niveau==4:
		#QIX
		taille_qix=50
		xq=xa_map+cote_map/2
		yq=ya_map+cote_map/2
		tempsqix=time()
		direction=randint(1,4)
		position_precedente=None
		liste_qix=[[xq,yq,None],[xq,yq,None]]
		vitesse_qix=5
		temps_deplacement_qix=time()
		latence_qix=0.019

		#SPARX
		xs = xa_map + cote_map / 2
		ys = ya_map
		xs2= xa_map + cote_map / 2
		ys2= ya_map
		xs3= xa_map
		ys3= ya_map + cote_map / 2
		xs4= xa_map + cote_map
		ys4= ya_map + cote_map / 2
		liste_sparx=[(xs,ys),(xs2,ys2),(xs3,ys3),(xs4,ys4)]
		vitesse_sparx=5
		temps_sparx=time()
		latence_sparx=0.019
	elif Niveau==5:
		#QIX
		taille_qix=50
		xq=xa_map+cote_map/2
		yq=ya_map+cote_map/2
		tempsqix=time()
		direction=randint(1,4)
		position_precedente=None
		liste_qix=[[xq,yq,None],[xq,yq,None],[xq,yq,None]]
		vitesse_qix=5
		temps_deplacement_qix=time()
		latence_qix=0.019
		#SPARX
		xs = xa_map + cote_map / 2
		ys = ya_map
		xs2= xa_map + cote_map / 2
		ys2= ya_map
		xs3= xa_map
		ys3= ya_map + cote_map / 2
		xs4= xa_map + cote_map
		ys4= ya_map + cote_map / 2
		liste_sparx=[(xs,ys),(xs2,ys2),(xs3,ys3),(xs4,ys4)]
		vitesse_sparx=5
		
		temps_sparx=time()
		latence_sparx=0.019

		
		
		
		
		
		
		
	if Mode_de_jeu=="1 JOUEUR":	
		return cote_map,xa_map,ya_map,liste_bord,pourcentage,Score,Air_total,Air_rempli,mode,vie_joueur,xj,yj,lst_dessin,vitesse_joueur,delais_deplacement,Invincibilite,temps_invincibilite,delaismode,delaisvitesse,direction_interdite,liste_joueur,liste_dessins,lst_dessin2,lst_trainee,taille_qix,tempsqix,direction,position_precedente,liste_qix,liste_sparx,presence_obstacle,liste_obstacle,tempsobstacle,pommes, vitesse_qix, vitesse_sparx, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu,bm,delais_bonus,color1,color2
	else:
		return cote_map, xa_map, ya_map, liste_bord, pourcentage, Score, Air_total, Air_rempli, mode, vie_joueur, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2, vie_joueur_2, xj_2, yj_2, lst_dessin_2, vitesse_joueur_2, delais_deplacement_2, Invincibilite_2, temps_invincibilite_2, delaismode_2, delaisvitesse_2, direction_interdite_2, Score_2, liste_dessins_2, lst_trainee_2, lst_dessin2_2,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,delais_bonus,color1,color2
		
def sauvegarder(fichier_sauvegarde,sauvegarde,liste_parametre):
	fichier=open(fichier_sauvegarde,'r')
	a=fichier.readlines()
	fichier.close()
	i=0
	b=[]
	while i<(len(a)):
		if a[i]==sauvegarde+"\n":
			b.append(a[i])
			b.extend(liste_parametre)
			while i!=len(a) and sauvegarde[:-1]+str(int(sauvegarde[-1])+1)!=a[i][:-1] :
				i+=1


		else:
			b.append(a[i])
			i+=1
	fichier = open(fichier_sauvegarde, 'w')
	fichier.writelines(b)
	fichier.close()

def charger_sauvegarde(sauvegarde,liste_sauvegarde):
	return liste_sauvegarde[int(sauvegarde[-1])-1]
def choix_sauvegarde_charger(liste_sauvegarde):
	x2, y2 = attend_clic_gauche()
	while not (x2 < 55 and y2 < 55 and x2 > 5 and y2 > 5) and not (
			x2 > 0 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 1 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 1 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 2 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 2 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 3 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 3 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 4 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200) and not (
			x2 > 4 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 5 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200):
		x2, y2 = attend_clic_gauche()
	if x2 < 55 and y2 < 55 and x2 > 5 and y2 > 5:
		efface_tout()
		return "QUITTER"
	if x2 > 0 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 1 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		return charger_sauvegarde("SAUVEGARDE 1",liste_sauvegarde)

	if x2 > 1 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 2 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		return charger_sauvegarde("SAUVEGARDE 2",liste_sauvegarde)

	if x2 > 2 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 3 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		return charger_sauvegarde("SAUVEGARDE 3",liste_sauvegarde)

	if x2 > 3 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 4 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		return charger_sauvegarde("SAUVEGARDE 4",liste_sauvegarde)

	if x2 > 4 * (largeur_fenetre / 5) + 10 and y2 > hauteur_fenetre / 2 - 200 and x2 < 5 * (
			largeur_fenetre / 5) - 10 and y2 < hauteur_fenetre / 2 + 200:
		efface_tout()
		return charger_sauvegarde("SAUVEGARDE 5",liste_sauvegarde)
		
if __name__ == '__main__':
	#AFFICHAGE FENETRE
	largeur_fenetre=1420
	hauteur_fenetre=820		
	cree_fenetre(largeur_fenetre,hauteur_fenetre)
	#AFFICHAGE MENU
	while True:
		Mode_de_jeu=Interface()
		Niveau=1
		#INITIALISATION DES VALEURS
		if Mode_de_jeu=="1 JOUEUR":
			cote_map,xa_map,ya_map,liste_bord,pourcentage,Score,Air_total,Air_rempli,mode,vie_joueur,xj,yj,lst_dessin,vitesse_joueur,delais_deplacement,Invincibilite,temps_invincibilite,delaismode,delaisvitesse,direction_interdite,liste_joueur,liste_dessins,lst_dessin2,lst_trainee,taille_qix,tempsqix,direction,position_precedente,liste_qix,liste_sparx,presence_obstacle,liste_obstacle,tempsobstacle,pommes,vitesse_qix,vitesse_sparx,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,delais_bonus,color1,color2=Initialisation(Niveau,Mode_de_jeu)
		elif Mode_de_jeu=="2 JOUEUR":
			cote_map, xa_map, ya_map, liste_bord, pourcentage, Score, Air_total, Air_rempli, mode, vie_joueur, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2, vie_joueur_2, xj_2, yj_2, lst_dessin_2, vitesse_joueur_2, delais_deplacement_2, Invincibilite_2, temps_invincibilite_2, delaismode_2, delaisvitesse_2, direction_interdite_2, Score_2, liste_dessins_2, lst_trainee_2, lst_dessin2_2,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,delais_bonus,color1,color2=Initialisation(Niveau,Mode_de_jeu)
		while Mode_de_jeu == "Sauvegarde":
			liste_sauvegarde = affiche_sauvegarde("Sauvegarde.txt", largeur_fenetre, hauteur_fenetre)
			a = choix_sauvegarde_charger(liste_sauvegarde)
			if a=="QUITTER" or a[1]=="VIDE":
				Mode_de_jeu = Interface()
			if a[1] == "1 JOUEUR":
				Mode_de_jeu, Niveau, pourcentage, vie_joueur, cote_map, cote_map, xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu, bm,color1, color2, delais_bonus=a[1:]
				Mode_de_jeu, Niveau, pourcentage, vie_joueur, cote_map, cote_map, xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu ,bm,color1, color2, delais_bonus= (
					Mode_de_jeu, int(Niveau), float(pourcentage), int(vie_joueur), int(cote_map), int(cote_map),
					float(xa_map), float(ya_map), eval(liste_bord), float(Score), float(Air_total), float(Air_rempli), mode,
					float(xj), float(yj), eval(lst_dessin), vitesse_joueur, float(delais_deplacement), bool(Invincibilite),
					float(temps_invincibilite), float(delaismode), float(delaisvitesse), tuple(direction_interdite),
					eval(liste_joueur), eval(liste_dessins), eval(lst_dessin2), eval(lst_trainee), float(taille_qix),
					float(tempsqix), tuple(direction), tuple(position_precedente), eval(liste_qix), eval(liste_sparx),
					bool(presence_obstacle), eval(liste_obstacle), float(tempsobstacle), eval(pommes), int(vitesse_qix),
					int(vitesse_sparx), float(temps_deplacement_qix), float(latence_qix), float(temps_sparx),
					float(latence_sparx), float(latence_jeu),eval(bm),color1, color2, float(delais_bonus)
				)
				break
			if a[1]=="2 JOUEUR":

				Mode_de_jeu, Niveau, pourcentage, vie_joueur, vie_joueur_2,cote_map, cote_map, xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2,xj_2,yj_2,lst_dessin_2,vitesse_joueur_2 ,delais_deplacement_2,Invincibilite_2,temps_invincibilite_2,delaisvitesse_2,Score_2,liste_dessins_2,lst_trainee_2,lst_dessin2_2,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu, bm, color1, color2, delais_bonus, delaismode_2,direction_interdite_2=a[1:]
				Mode_de_jeu, Niveau, pourcentage, vie_joueur, vie_joueur_2, cote_map, cote_map, xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2, xj_2, yj_2, lst_dessin_2, vitesse_joueur_2, delais_deplacement_2, Invincibilite_2, temps_invincibilite_2, delaisvitesse_2, Score_2, liste_dessins_2, lst_trainee_2, lst_dessin2_2, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu, bm,color1, color2, delais_bonus,delaismode_2,direction_interdite_2 = (
					Mode_de_jeu, int(Niveau), float(pourcentage), int(vie_joueur), int(vie_joueur_2), int(cote_map),
					int(cote_map),
					float(xa_map), float(ya_map), eval(liste_bord), float(Score), float(Air_total), float(Air_rempli), mode,
					float(xj), float(yj), eval(lst_dessin), vitesse_joueur, float(delais_deplacement), bool(Invincibilite),
					float(temps_invincibilite), float(delaismode), float(delaisvitesse), tuple(direction_interdite),
					eval(liste_joueur), eval(liste_dessins), eval(lst_dessin2), eval(lst_trainee), float(taille_qix),
					float(tempsqix), tuple(direction), tuple(position_precedente), eval(liste_qix), eval(liste_sparx),
					bool(presence_obstacle), eval(liste_obstacle), float(tempsobstacle), eval(pommes), int(vitesse_qix),
					int(vitesse_sparx), str(mode_2), float(xj_2), float(yj_2), eval(lst_dessin_2),
					vitesse_joueur_2,
					float(delais_deplacement_2), bool(Invincibilite_2), float(temps_invincibilite_2),
					float(delaisvitesse_2),
					float(Score_2), eval(liste_dessins_2), eval(lst_trainee_2), eval(lst_dessin2_2),
					float(temps_deplacement_qix),
					float(latence_qix), float(temps_sparx), float(latence_sparx), float(latence_jeu),eval(bm),color1, color2 ,float(delais_bonus),float(delaismode_2),tuple(direction_interdite_2),
				)
				break


			if Mode_de_jeu == "1 JOUEUR":
				cote_map, xa_map, ya_map, liste_bord, pourcentage, Score, Air_total, Air_rempli, mode, vie_joueur, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu,bm,delais_bonus,color1,color2= Initialisation(
					Niveau, Mode_de_jeu)
				break
			elif Mode_de_jeu == "2 JOUEUR":
				cote_map, xa_map, ya_map, liste_bord, pourcentage, Score, Air_total, Air_rempli, mode, vie_joueur, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2, vie_joueur_2, xj_2, yj_2, lst_dessin_2, vitesse_joueur_2, delais_deplacement_2, Invincibilite_2, temps_invincibilite_2, delaismode_2, delaisvitesse_2, direction_interdite_2, Score_2, liste_dessins_2, lst_trainee_2, lst_dessin2_2, temps_deplacement_qix, latence_qix, temps_sparx, latence_sparx, latence_jeu,bm,delais_bonus,color1,color2 = Initialisation(
					Niveau, Mode_de_jeu)
				break
			attend_clic_gauche()


		mise_a_jour()
		if Mode_de_jeu=="1 JOUEUR":
			while True:
				if touche_pressee("Escape"):
					affiche_menu()
					choix_menu([str(element) + '\n' for element in[Mode_de_jeu, Niveau, pourcentage, vie_joueur, cote_map, cote_map,xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj,yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite,temps_invincibilite, delaismode, delaisvitesse, direction_interdite,liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix,tempsqix, direction, position_precedente, liste_qix, liste_sparx,presence_obstacle, liste_obstacle, tempsobstacle, pommes,vitesse_qix, vitesse_sparx, temps_deplacement_qix, latence_qix,temps_sparx, latence_sparx, latence_jeu,bm,color1, color2,delais_bonus]])

				if time()-latence_jeu>0.019:
					latence_jeu=time()


					if pourcentage>=75:
						Niveau=Niveau_gagner(Niveau)
						if Niveau==6:
							break
						cote_map,xa_map,ya_map,liste_bord,pourcentage,Score,Air_total,Air_rempli,mode,vie_joueur,xj,yj,lst_dessin,vitesse_joueur,delais_deplacement,Invincibilite,temps_invincibilite,delaismode,delaisvitesse,direction_interdite,liste_joueur,liste_dessins,lst_dessin2,lst_trainee,taille_qix,tempsqix,direction,position_precedente,liste_qix,liste_sparx,presence_obstacle,liste_obstacle,tempsobstacle,pommes,vitesse_qix,vitesse_sparx,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,delais_bonus,color1,color2=Initialisation(Niveau,Mode_de_jeu)


						attend_ev()
					elif vie_joueur>0:
						efface_tout()
						affiche_jeu()
						#============AFFICHAGE INFOS==============
						if (xj,yj) in liste_bord:
							mode,delaismode=changement_mode(mode,delaismode,1)
						pourcentage=calcul_pourcentage_total(liste_bord,Air_total)
						affiche_pourcentage(pourcentage)
						Score=score(liste_dessins,Air_total)
						affiche_pomme(pommes)
						affiche_bonus(bm)
						affiche_info_joueur(1,Score,vie_joueur,mode,vitesse_joueur)

						#===========AFFICHAGE ELEMENT DU JEU===============
						temps_restant_invincible=time()-temps_invincibilite
						if Invincibilite==True and temps_restant_invincible>3:
							Invincibilite=False
						affiche_qix(liste_qix, color1, color2)
						if color1 != "white":
							if time() - delais_bonus > 15:
								delais_bonus = time()
								color1, color2 = "white", "blue"
						if liste_dessins!=[]:
							affiche_dessins(liste_dessins)
						if lst_trainee!=[]:
							affiche_trainee(lst_trainee)
						if (xj,yj) in liste_bord:
							vitesse_joueur,delaisvitesse=changement_vitesse(vitesse_joueur,delaisvitesse,1)

						if mode=="DESSIN":
							if (xj,yj) not in liste_bord:
								if vitesse_joueur=="LENT":
									if time()-delais_deplacement>0.076:
										delais_deplacement=time()
										for i in range(5):
											xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
											if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
												mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
												break
											if collision_trainee(lst_trainee,xj,yj)==True :
												if Invincibilite==True:
													mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
													break
												else:
													mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
													break


											pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
											bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
												xj, yj, bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur,
												delais_deplacement, color1, color2)
											if bm == []:

												bm=creation_bonus(1)
								else:
									lst_trainee==[]
									if time()-delais_deplacement>0.038:
										delais_deplacement=time()
										for i in range(5):
											xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
											if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
												mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
												break
											if collision_trainee(lst_trainee,xj,yj)==True:
												if Invincibilite==True:
													mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
												else:
													mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
												break
											pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
											bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
												xj, yj, bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur,
												delais_deplacement, color1, color2)

											if bm == []:

												bm=creation_bonus(1)
							else:
								if time()-delais_deplacement>0.038:
									delais_deplacement=time()
									for i in range(5):
										xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
										if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
											mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
											break
										if collision_trainee(lst_trainee,xj,yj)==True:
											if Invincibilite==True:
												mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
											else:
												mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
											break
										pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
										bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
											xj, yj, bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur,
											delais_deplacement, color1, color2)

										if bm == []:

											bm=creation_bonus(1)
						else:
							lst_dessin=[]
							lst_trainee=[]
							if time()-delais_deplacement>0.038:
								delais_deplacement=time()
								for i in range(5):
									xj,yj=deplacement_joueur_base(xj,yj,1,liste_bord)
									if (collision_sparx(xj,yj,liste_sparx)==True)and Invincibilite==False:
										mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
										break
						if Invincibilite==False:
							affiche_joueur(xj,yj,"red")
						else:
							affiche_joueur(xj,yj,"aquamarine")

				#========================================= QIX =========================================
				#=======================================================================================
						if time() - tempsqix > 0.25:
							changement_direction_qix(liste_qix)
							tempsqix=time()

						if time()-temps_deplacement_qix>latence_qix:
							temps_deplacement_qix=time()
							if collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord) and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
							deplacement_qixs(liste_qix,tempsqix,vitesse_qix)
							if collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord) and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)



				#===================================OBSTACLES==========================
						if time()-tempsobstacle>10:
							tempsobstacle=time()
							liste_obstacle=(coordonnee_obstacles(2))
						affiche_obstacle(liste_obstacle)
				#===================================SPARX==============================
						if time()-temps_sparx>latence_sparx:
							temps_sparx=time()
							if collision_sparx(xj,yj,liste_sparx)==True and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
							deplacement_sparxs(liste_sparx,liste_qix,vitesse_sparx,liste_bord)
							if collision_sparx(xj,yj,liste_sparx)==True and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
						affiche_sparx(liste_sparx)
					if vie_joueur==0:
						perdu()
						attend_clic_gauche()
						break
					mise_a_jour()

		elif Mode_de_jeu=="2 JOUEUR":
			while True:
				if time()-latence_jeu>0.019:
					latence_jeu=time()
					if touche_pressee("Escape"):
						affiche_menu()
						choix_menu([str(element) + '\n' for element in[Mode_de_jeu, Niveau, pourcentage, vie_joueur,vie_joueur_2, cote_map, cote_map, xa_map, ya_map, liste_bord, Score, Air_total, Air_rempli, mode, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2,xj_2,yj_2,lst_dessin_2,vitesse_joueur_2 ,delais_deplacement_2,Invincibilite_2,temps_invincibilite_2,delaisvitesse_2,Score_2,liste_dessins_2,lst_trainee_2,lst_dessin2_2,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,color1, color2,delais_bonus, delaismode_2, direction_interdite_2]])

					if pourcentage>=75:
						Niveau=Niveau_gagner(Niveau)
						if Niveau==6:
							break
						cote_map, xa_map, ya_map, liste_bord, pourcentage, Score, Air_total, Air_rempli, mode, vie_joueur, xj, yj, lst_dessin, vitesse_joueur, delais_deplacement, Invincibilite, temps_invincibilite, delaismode, delaisvitesse, direction_interdite, liste_joueur, liste_dessins, lst_dessin2, lst_trainee, taille_qix, tempsqix, direction, position_precedente, liste_qix, liste_sparx, presence_obstacle, liste_obstacle, tempsobstacle, pommes, vitesse_qix, vitesse_sparx, mode_2, vie_joueur_2, xj_2, yj_2, lst_dessin_2, vitesse_joueur_2, delais_deplacement_2, Invincibilite_2, temps_invincibilite_2, delaismode_2, delaisvitesse_2, direction_interdite_2, Score_2, liste_dessins_2, lst_trainee_2, lst_dessin2_2,temps_deplacement_qix,latence_qix,temps_sparx,latence_sparx,latence_jeu,bm,delais_bonus,color1,color2=Initialisation(Niveau,Mode_de_jeu)

						attend_ev()
					elif vie_joueur>0 or vie_joueur_2>0:
						efface_tout()
						affiche_jeu()
						#============AFFICHAGE INFOS==============
						if (xj,yj) in liste_bord:
							mode,delaismode=changement_mode(mode,delaismode,1)
						if (xj_2,yj_2) in liste_bord:
							mode_2,delaismode_2=changement_mode(mode_2,delaismode_2,2)
						pourcentage=calcul_pourcentage_total(liste_bord,Air_total)
						affiche_pourcentage(pourcentage)
						Score=score(liste_dessins,Air_total)
						Score_2=score(liste_dessins_2,Air_total)
						affiche_pomme(pommes)
						affiche_bonus(bm)
						affiche_info_joueur(1, Score, vie_joueur, mode, vitesse_joueur)
						affiche_info_joueur(2, Score_2, vie_joueur_2, mode_2, vitesse_joueur_2)
						if liste_dessins_2!=[]:
							affiche_dessins(liste_dessins_2)
						if liste_dessins!=[]:
							affiche_dessins(liste_dessins)

						#===========AFFICHAGE ELEMENT DU JEU===============
						if vie_joueur>0:
							temps_restant_invincible=time()-temps_invincibilite
							if Invincibilite==True and temps_restant_invincible>3:
								Invincibilite=False
							if color1 != "white":
								if time() - delais_bonus > 15:
									delais_bonus = time()
									color1, color2 = "white", "blue"

							if lst_trainee!=[]:
								affiche_trainee(lst_trainee)
							if (xj,yj) in liste_bord:
								vitesse_joueur,delaisvitesse=changement_vitesse(vitesse_joueur,delaisvitesse,1)
							if est_point_dans_polygone((xj,yj),sommet_polygone(liste_bord)) or(xj,yj) in liste_bord:

								if mode=="DESSIN":
									if (xj,yj) not in liste_bord:
										if vitesse_joueur=="LENT":
											if time()-delais_deplacement>0.076:
												delais_deplacement=time()
												for i in range(5):
													xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
													if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
														mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														break
													if collision_trainee(lst_trainee,xj,yj)==True or collision_trainee(lst_trainee_2,xj,yj)==True:
														if Invincibilite==True:
															mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														else:
															mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														break


													pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
													bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
														xj, yj, bm, temps_deplacement_qix, temps_sparx, Score,
														vie_joueur,
														delais_deplacement, color1, color2)
													if bm == []:
														bm = creation_bonus(1)
										else:
											lst_trainee==[]
											if time()-delais_deplacement>0.038:
												delais_deplacement=time()
												for i in range(5):
													xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
													if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
														mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														break
													if collision_trainee(lst_trainee,xj,yj)==True  or collision_trainee(lst_trainee_2,xj,yj)==True:
														if Invincibilite==True:
															mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														else:
															mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
														break
													pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
													bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
														xj, yj, bm, temps_deplacement_qix, temps_sparx, Score,
														vie_joueur,
														delais_deplacement, color1, color2)
													if bm == []:
														bm = creation_bonus(1)
									else:
										if time()-delais_deplacement>0.038:
											delais_deplacement=time()
											for i in range(5):
												xj,yj,direction_interdite,mode=deplacement_joueur_dessin(xj,yj,lst_dessin,lst_trainee,mode,liste_dessins,vitesse_joueur,direction_interdite,1,liste_bord)
												if (collision_sparx(xj,yj,liste_sparx)==True or collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord)==True)and Invincibilite==False:
													mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
													break
												if collision_trainee(lst_trainee,xj,yj)==True or collision_trainee(lst_trainee_2,xj,yj)==True:
													if Invincibilite==True:
														mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
													else:
														mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
													break
												pommes,Invincibilite,temps_invincibilite=mange_pomme(xj,yj,pommes,Invincibilite,temps_invincibilite)
												bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur, delais_deplacement, color1, color2 = mange_bonus(
													xj, yj, bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur,
													delais_deplacement, color1, color2)
												if bm == []:
													bm = creation_bonus(1)
								else:
									lst_dessin=[]
									lst_trainee=[]
									if time()-delais_deplacement>0.038:
										delais_deplacement=time()
										for i in range(5):
											xj,yj=deplacement_joueur_base(xj,yj,1,liste_bord)
											if (collision_sparx(xj,yj,liste_sparx)==True)and Invincibilite==False:
												mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
												break

								if Invincibilite==False:
									affiche_joueur(xj,yj,"red")
								else:
									affiche_joueur(xj,yj,"aquamarine")
							else:
								for qix in liste_qix:
									xq,yq,direction=qix
									if est_point_dans_polygone((xq,yq),sommet_polygone(liste_bord)):
										if xq>xj:
											xj+=1
										if xq<xj:
											xj-=1
										if yq>yj:
											yj+=1
										if yq<yj:
											yj-=1
								affiche_joueur(xj,yj,"aquamarine")
								if (xj,yj) in liste_bord:
									if Invincibilite==True:
										mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=reapparition(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
									else:
										mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)





				#========================================JOUEUR 2=====================================
						if vie_joueur_2>0:
							temps_restant_invincible_2=time()-temps_invincibilite_2
							if Invincibilite_2==True and temps_restant_invincible_2>3:
								Invincibilite_2=False
							if lst_trainee_2!=[]:
								affiche_trainee(lst_trainee_2)
							if (xj_2,yj_2) in liste_bord:
								vitesse_joueur_2,delaisvitesse_2=changement_vitesse(vitesse_joueur_2,delaisvitesse_2,2)
							if est_point_dans_polygone((xj_2,yj_2),sommet_polygone(liste_bord)) or(xj_2,yj_2) in liste_bord:

								if mode_2=="DESSIN":
									if (xj_2,yj_2) not in liste_bord:
										if vitesse_joueur_2=="LENT":
											if time()-delais_deplacement_2>0.076:
												delais_deplacement_2=time()
												for i in range(5):
													xj_2,yj_2,direction_interdite_2,mode_2=deplacement_joueur_dessin(xj_2,yj_2,lst_dessin_2,lst_trainee_2,mode_2,liste_dessins_2,vitesse_joueur_2,direction_interdite_2,2,liste_bord)
													if (collision_sparx(xj_2,yj_2,liste_sparx)==True or collision_qix(xj_2,yj_2,liste_qix,lst_trainee_2,liste_bord)==True)and Invincibilite_2==False:
														mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														break
													if collision_trainee(lst_trainee,xj_2,yj_2)==True or collision_trainee(lst_trainee,xj_2,yj_2)==True:
														if Invincibilite_2==True:
															mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=reapparition(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														else:
															mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														break


													pommes,Invincibilite_2,temps_invincibilite_2=mange_pomme(xj_2,yj_2,pommes,Invincibilite_2,temps_invincibilite_2)
													bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur_2, delais_deplacement_2, color1, color2 = mange_bonus(
														xj_2, yj_2, bm, temps_deplacement_qix, temps_sparx, Score,
														vie_joueur_2,
														delais_deplacement_2, color1, color2)
													if bm == []:
														bm = creation_bonus(1)
										else:
											lst_trainee_2==[]
											if time()-delais_deplacement_2>0.038:
												delais_deplacement_2=time()
												for i in range(5):
													xj_2,yj_2,direction_interdite_2,mode_2=deplacement_joueur_dessin(xj_2,yj_2,lst_dessin_2,lst_trainee_2,mode_2,liste_dessins_2,vitesse_joueur_2,direction_interdite_2,2,liste_bord)
													if (collision_sparx(xj_2,yj_2,liste_sparx)==True or collision_qix(xj_2,yj_2,liste_qix,lst_trainee_2,liste_bord)==True)and Invincibilite_2==False:
														mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														break
													if collision_trainee(lst_trainee_2,xj_2,yj_2)==True or collision_trainee(lst_trainee,xj_2,yj_2)==True:
														if Invincibilite_2==True:
															mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=reapparition(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														else:
															mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
														break
													pommes,Invincibilite_2,temps_invincibilite_2=mange_pomme(xj_2,yj_2,pommes,Invincibilite_2,temps_invincibilite_2)
													bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur_2, delais_deplacement_2, color1, color2 = mange_bonus(
														xj_2, yj_2, bm, temps_deplacement_qix, temps_sparx, Score,
														vie_joueur_2,
														delais_deplacement_2, color1, color2)
													if bm == []:
														bm = creation_bonus(1)
									else:
										if time()-delais_deplacement_2>0.038:
											delais_deplacement_2=time()
											for i in range(5):
												xj_2,yj_2,direction_interdite_2,mode_2=deplacement_joueur_dessin(xj_2,yj_2,lst_dessin_2,lst_trainee_2,mode_2,liste_dessins_2,vitesse_joueur_2,direction_interdite_2,2,liste_bord)
												if (collision_sparx(xj_2,yj_2,liste_sparx)==True or collision_qix( xj_2, yj_2, liste_qix, lst_trainee_2, liste_bord)==True)and Invincibilite_2==False:
													mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
													break
												if collision_trainee(lst_trainee_2,xj_2,yj_2)==True or collision_trainee(lst_trainee,xj_2,yj_2)==True:
													if Invincibilite_2==True:
														mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=reapparition(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
													else:
														mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
													break
												pommes,Invincibilite_2,temps_invincibilite_2=mange_pomme(xj_2,yj_2,pommes,Invincibilite_2,temps_invincibilite_2)
												bm, temps_deplacement_qix, temps_sparx, Score, vie_joueur_2, delais_deplacement_2, color1, color2 = mange_bonus(
													xj_2, yj_2, bm, temps_deplacement_qix, temps_sparx, Score,
													vie_joueur_2,
													delais_deplacement_2, color1, color2)
												if bm == []:
													bm = creation_bonus(1)
								else:
									lst_dessin_2=[]
									lst_trainee_2=[]
									if time()-delais_deplacement_2>0.038:
										delais_deplacement_2=time()
										for i in range(5):
											xj_2,yj_2=deplacement_joueur_base(xj_2,yj_2,2,liste_bord)
											if (collision_sparx(xj_2,yj_2,liste_sparx)==True)and Invincibilite_2==False:
												mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
												break
								if Invincibilite_2==False:
									affiche_joueur(xj_2,yj_2,"purple")
								else:
									affiche_joueur(xj_2,yj_2,"aquamarine")
							else:
								for qix in liste_qix:
									xq,yq,direction=qix
									if est_point_dans_polygone((xq,yq),sommet_polygone(liste_bord)):
										if xq>xj_2:
											xj_2+=1
										if xq<xj_2:
											xj_2-=1
										if yq>yj_2:
											yj_2+=1
										if yq<yj_2:
											yj_2-=1
								affiche_joueur(xj_2,yj_2,"aquamarine")
								if (xj_2,yj_2) in liste_bord:
									if Invincibilite==True:
										mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=reapparition(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
									else:
										mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)

				#========================================= QIX =========================================
				#=======================================================================================
						if time() - tempsqix > 0.25:
							changement_direction_qix(liste_qix)
							tempsqix=time()
						if time()-temps_deplacement_qix>latence_qix:
							temps_deplacement_qix=time()
							deplacement_qixs(liste_qix,tempsqix,vitesse_qix)
							if collision_qix(xj,yj,liste_qix,lst_trainee,liste_bord) and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
							if collision_qix(xj_2,yj_2,liste_qix,lst_trainee_2,liste_bord) and Invincibilite_2==False:
								mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)

						affiche_qix(liste_qix,color1,color2)

				#===================================OBSTACLES==========================
						if time()-tempsobstacle>10:
							tempsobstacle=time()
							liste_obstacle=(coordonnee_obstacles(2))
						affiche_obstacle(liste_obstacle)
						print(liste_obstacle)

						#===================================SPARX==============================
						if time()-temps_sparx>latence_sparx:
							temps_sparx=time()
							deplacement_sparxs(liste_sparx,liste_qix,vitesse_sparx,liste_bord)
							if collision_sparx(xj,yj,liste_sparx)==True and Invincibilite==False:
								mode,vie_joueur,xj,yj,Invincibilite,temps_invincibilite=perte_vie(mode,vie_joueur,xj,yj,lst_dessin,lst_trainee,liste_bord)
							if collision_sparx(xj_2,yj_2,liste_sparx)==True and Invincibilite_2==False:
								mode_2,vie_joueur_2,xj_2,yj_2,Invincibilite_2,temps_invincibilite_2=perte_vie(mode_2,vie_joueur_2,xj_2,yj_2,lst_dessin_2,lst_trainee_2,liste_bord)
						affiche_sparx(liste_sparx)


					if vie_joueur==0 and vie_joueur_2==0:
						perdu()
						attend_clic_gauche()
						break

					mise_a_jour()





